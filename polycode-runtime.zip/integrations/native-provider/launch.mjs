// @bun
var __create = Object.create;
var __getProtoOf = Object.getPrototypeOf;
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
function __accessProp(key) {
  return this[key];
}
var __toESMCache_node;
var __toESMCache_esm;
var __toESM = (mod, isNodeMode, target) => {
  var canCache = mod != null && typeof mod === "object";
  if (canCache) {
    var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
    var cached = cache.get(mod);
    if (cached)
      return cached;
  }
  target = mod != null ? __create(__getProtoOf(mod)) : {};
  const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
  for (let key of __getOwnPropNames(mod))
    if (!__hasOwnProp.call(to, key))
      __defProp(to, key, {
        get: __accessProp.bind(mod, key),
        enumerable: true
      });
  if (canCache)
    cache.set(mod, to);
  return to;
};
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __returnValue = (v) => v;
function __exportSetter(name, newValue) {
  this[name] = __returnValue.bind(null, newValue);
}
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, {
      get: all[name],
      enumerable: true,
      configurable: true,
      set: __exportSetter.bind(all, name)
    });
};
var __esm = (fn, res) => () => (fn && (res = fn(fn = 0)), res);
var __require = import.meta.require;

// integrations/native-provider/node_modules/graceful-fs/polyfills.js
var require_polyfills = __commonJS((exports, module) => {
  var constants = __require("constants");
  var origCwd = process.cwd;
  var cwd = null;
  var platform = process.env.GRACEFUL_FS_PLATFORM || process.platform;
  process.cwd = function() {
    if (!cwd)
      cwd = origCwd.call(process);
    return cwd;
  };
  try {
    process.cwd();
  } catch (er) {}
  if (typeof process.chdir === "function") {
    chdir = process.chdir;
    process.chdir = function(d) {
      cwd = null;
      chdir.call(process, d);
    };
    if (Object.setPrototypeOf)
      Object.setPrototypeOf(process.chdir, chdir);
  }
  var chdir;
  module.exports = patch;
  function patch(fs) {
    if (constants.hasOwnProperty("O_SYMLINK") && process.version.match(/^v0\.6\.[0-2]|^v0\.5\./)) {
      patchLchmod(fs);
    }
    if (!fs.lutimes) {
      patchLutimes(fs);
    }
    fs.chown = chownFix(fs.chown);
    fs.fchown = chownFix(fs.fchown);
    fs.lchown = chownFix(fs.lchown);
    fs.chmod = chmodFix(fs.chmod);
    fs.fchmod = chmodFix(fs.fchmod);
    fs.lchmod = chmodFix(fs.lchmod);
    fs.chownSync = chownFixSync(fs.chownSync);
    fs.fchownSync = chownFixSync(fs.fchownSync);
    fs.lchownSync = chownFixSync(fs.lchownSync);
    fs.chmodSync = chmodFixSync(fs.chmodSync);
    fs.fchmodSync = chmodFixSync(fs.fchmodSync);
    fs.lchmodSync = chmodFixSync(fs.lchmodSync);
    fs.stat = statFix(fs.stat);
    fs.fstat = statFix(fs.fstat);
    fs.lstat = statFix(fs.lstat);
    fs.statSync = statFixSync(fs.statSync);
    fs.fstatSync = statFixSync(fs.fstatSync);
    fs.lstatSync = statFixSync(fs.lstatSync);
    if (fs.chmod && !fs.lchmod) {
      fs.lchmod = function(path, mode, cb) {
        if (cb)
          process.nextTick(cb);
      };
      fs.lchmodSync = function() {};
    }
    if (fs.chown && !fs.lchown) {
      fs.lchown = function(path, uid, gid, cb) {
        if (cb)
          process.nextTick(cb);
      };
      fs.lchownSync = function() {};
    }
    if (platform === "win32") {
      fs.rename = typeof fs.rename !== "function" ? fs.rename : function(fs$rename) {
        function rename(from, to, cb) {
          var start = Date.now();
          var backoff = 0;
          fs$rename(from, to, function CB(er) {
            if (er && (er.code === "EACCES" || er.code === "EPERM" || er.code === "EBUSY") && Date.now() - start < 60000) {
              setTimeout(function() {
                fs.stat(to, function(stater, st) {
                  if (stater && stater.code === "ENOENT")
                    fs$rename(from, to, CB);
                  else
                    cb(er);
                });
              }, backoff);
              if (backoff < 100)
                backoff += 10;
              return;
            }
            if (cb)
              cb(er);
          });
        }
        if (Object.setPrototypeOf)
          Object.setPrototypeOf(rename, fs$rename);
        return rename;
      }(fs.rename);
    }
    fs.read = typeof fs.read !== "function" ? fs.read : function(fs$read) {
      function read(fd, buffer, offset, length, position, callback_) {
        var callback;
        if (callback_ && typeof callback_ === "function") {
          var eagCounter = 0;
          callback = function(er, _, __) {
            if (er && er.code === "EAGAIN" && eagCounter < 10) {
              eagCounter++;
              return fs$read.call(fs, fd, buffer, offset, length, position, callback);
            }
            callback_.apply(this, arguments);
          };
        }
        return fs$read.call(fs, fd, buffer, offset, length, position, callback);
      }
      if (Object.setPrototypeOf)
        Object.setPrototypeOf(read, fs$read);
      return read;
    }(fs.read);
    fs.readSync = typeof fs.readSync !== "function" ? fs.readSync : function(fs$readSync) {
      return function(fd, buffer, offset, length, position) {
        var eagCounter = 0;
        while (true) {
          try {
            return fs$readSync.call(fs, fd, buffer, offset, length, position);
          } catch (er) {
            if (er.code === "EAGAIN" && eagCounter < 10) {
              eagCounter++;
              continue;
            }
            throw er;
          }
        }
      };
    }(fs.readSync);
    function patchLchmod(fs2) {
      fs2.lchmod = function(path, mode, callback) {
        fs2.open(path, constants.O_WRONLY | constants.O_SYMLINK, mode, function(err, fd) {
          if (err) {
            if (callback)
              callback(err);
            return;
          }
          fs2.fchmod(fd, mode, function(err2) {
            fs2.close(fd, function(err22) {
              if (callback)
                callback(err2 || err22);
            });
          });
        });
      };
      fs2.lchmodSync = function(path, mode) {
        var fd = fs2.openSync(path, constants.O_WRONLY | constants.O_SYMLINK, mode);
        var threw = true;
        var ret;
        try {
          ret = fs2.fchmodSync(fd, mode);
          threw = false;
        } finally {
          if (threw) {
            try {
              fs2.closeSync(fd);
            } catch (er) {}
          } else {
            fs2.closeSync(fd);
          }
        }
        return ret;
      };
    }
    function patchLutimes(fs2) {
      if (constants.hasOwnProperty("O_SYMLINK") && fs2.futimes) {
        fs2.lutimes = function(path, at, mt, cb) {
          fs2.open(path, constants.O_SYMLINK, function(er, fd) {
            if (er) {
              if (cb)
                cb(er);
              return;
            }
            fs2.futimes(fd, at, mt, function(er2) {
              fs2.close(fd, function(er22) {
                if (cb)
                  cb(er2 || er22);
              });
            });
          });
        };
        fs2.lutimesSync = function(path, at, mt) {
          var fd = fs2.openSync(path, constants.O_SYMLINK);
          var ret;
          var threw = true;
          try {
            ret = fs2.futimesSync(fd, at, mt);
            threw = false;
          } finally {
            if (threw) {
              try {
                fs2.closeSync(fd);
              } catch (er) {}
            } else {
              fs2.closeSync(fd);
            }
          }
          return ret;
        };
      } else if (fs2.futimes) {
        fs2.lutimes = function(_a, _b, _c, cb) {
          if (cb)
            process.nextTick(cb);
        };
        fs2.lutimesSync = function() {};
      }
    }
    function chmodFix(orig) {
      if (!orig)
        return orig;
      return function(target, mode, cb) {
        return orig.call(fs, target, mode, function(er) {
          if (chownErOk(er))
            er = null;
          if (cb)
            cb.apply(this, arguments);
        });
      };
    }
    function chmodFixSync(orig) {
      if (!orig)
        return orig;
      return function(target, mode) {
        try {
          return orig.call(fs, target, mode);
        } catch (er) {
          if (!chownErOk(er))
            throw er;
        }
      };
    }
    function chownFix(orig) {
      if (!orig)
        return orig;
      return function(target, uid, gid, cb) {
        return orig.call(fs, target, uid, gid, function(er) {
          if (chownErOk(er))
            er = null;
          if (cb)
            cb.apply(this, arguments);
        });
      };
    }
    function chownFixSync(orig) {
      if (!orig)
        return orig;
      return function(target, uid, gid) {
        try {
          return orig.call(fs, target, uid, gid);
        } catch (er) {
          if (!chownErOk(er))
            throw er;
        }
      };
    }
    function statFix(orig) {
      if (!orig)
        return orig;
      return function(target, options, cb) {
        if (typeof options === "function") {
          cb = options;
          options = null;
        }
        function callback(er, stats) {
          if (stats) {
            if (stats.uid < 0)
              stats.uid += 4294967296;
            if (stats.gid < 0)
              stats.gid += 4294967296;
          }
          if (cb)
            cb.apply(this, arguments);
        }
        return options ? orig.call(fs, target, options, callback) : orig.call(fs, target, callback);
      };
    }
    function statFixSync(orig) {
      if (!orig)
        return orig;
      return function(target, options) {
        var stats = options ? orig.call(fs, target, options) : orig.call(fs, target);
        if (stats) {
          if (stats.uid < 0)
            stats.uid += 4294967296;
          if (stats.gid < 0)
            stats.gid += 4294967296;
        }
        return stats;
      };
    }
    function chownErOk(er) {
      if (!er)
        return true;
      if (er.code === "ENOSYS")
        return true;
      var nonroot = !process.getuid || process.getuid() !== 0;
      if (nonroot) {
        if (er.code === "EINVAL" || er.code === "EPERM")
          return true;
      }
      return false;
    }
  }
});

// integrations/native-provider/node_modules/graceful-fs/legacy-streams.js
var require_legacy_streams = __commonJS((exports, module) => {
  var Stream = __require("stream").Stream;
  module.exports = legacy;
  function legacy(fs) {
    return {
      ReadStream,
      WriteStream
    };
    function ReadStream(path, options) {
      if (!(this instanceof ReadStream))
        return new ReadStream(path, options);
      Stream.call(this);
      var self = this;
      this.path = path;
      this.fd = null;
      this.readable = true;
      this.paused = false;
      this.flags = "r";
      this.mode = 438;
      this.bufferSize = 64 * 1024;
      options = options || {};
      var keys = Object.keys(options);
      for (var index = 0, length = keys.length;index < length; index++) {
        var key = keys[index];
        this[key] = options[key];
      }
      if (this.encoding)
        this.setEncoding(this.encoding);
      if (this.start !== undefined) {
        if (typeof this.start !== "number") {
          throw TypeError("start must be a Number");
        }
        if (this.end === undefined) {
          this.end = Infinity;
        } else if (typeof this.end !== "number") {
          throw TypeError("end must be a Number");
        }
        if (this.start > this.end) {
          throw new Error("start must be <= end");
        }
        this.pos = this.start;
      }
      if (this.fd !== null) {
        process.nextTick(function() {
          self._read();
        });
        return;
      }
      fs.open(this.path, this.flags, this.mode, function(err, fd) {
        if (err) {
          self.emit("error", err);
          self.readable = false;
          return;
        }
        self.fd = fd;
        self.emit("open", fd);
        self._read();
      });
    }
    function WriteStream(path, options) {
      if (!(this instanceof WriteStream))
        return new WriteStream(path, options);
      Stream.call(this);
      this.path = path;
      this.fd = null;
      this.writable = true;
      this.flags = "w";
      this.encoding = "binary";
      this.mode = 438;
      this.bytesWritten = 0;
      options = options || {};
      var keys = Object.keys(options);
      for (var index = 0, length = keys.length;index < length; index++) {
        var key = keys[index];
        this[key] = options[key];
      }
      if (this.start !== undefined) {
        if (typeof this.start !== "number") {
          throw TypeError("start must be a Number");
        }
        if (this.start < 0) {
          throw new Error("start must be >= zero");
        }
        this.pos = this.start;
      }
      this.busy = false;
      this._queue = [];
      if (this.fd === null) {
        this._open = fs.open;
        this._queue.push([this._open, this.path, this.flags, this.mode, undefined]);
        this.flush();
      }
    }
  }
});

// integrations/native-provider/node_modules/graceful-fs/clone.js
var require_clone = __commonJS((exports, module) => {
  module.exports = clone;
  var getPrototypeOf = Object.getPrototypeOf || function(obj) {
    return obj.__proto__;
  };
  function clone(obj) {
    if (obj === null || typeof obj !== "object")
      return obj;
    if (obj instanceof Object)
      var copy = { __proto__: getPrototypeOf(obj) };
    else
      var copy = Object.create(null);
    Object.getOwnPropertyNames(obj).forEach(function(key) {
      Object.defineProperty(copy, key, Object.getOwnPropertyDescriptor(obj, key));
    });
    return copy;
  }
});

// integrations/native-provider/node_modules/graceful-fs/graceful-fs.js
var require_graceful_fs = __commonJS((exports, module) => {
  var fs = __require("fs");
  var polyfills = require_polyfills();
  var legacy = require_legacy_streams();
  var clone = require_clone();
  var util = __require("util");
  var gracefulQueue;
  var previousSymbol;
  if (typeof Symbol === "function" && typeof Symbol.for === "function") {
    gracefulQueue = Symbol.for("graceful-fs.queue");
    previousSymbol = Symbol.for("graceful-fs.previous");
  } else {
    gracefulQueue = "___graceful-fs.queue";
    previousSymbol = "___graceful-fs.previous";
  }
  function noop() {}
  function publishQueue(context, queue2) {
    Object.defineProperty(context, gracefulQueue, {
      get: function() {
        return queue2;
      }
    });
  }
  var debug = noop;
  if (util.debuglog)
    debug = util.debuglog("gfs4");
  else if (/\bgfs4\b/i.test(process.env.NODE_DEBUG || ""))
    debug = function() {
      var m = util.format.apply(util, arguments);
      m = "GFS4: " + m.split(/\n/).join(`
GFS4: `);
      console.error(m);
    };
  if (!fs[gracefulQueue]) {
    queue = global[gracefulQueue] || [];
    publishQueue(fs, queue);
    fs.close = function(fs$close) {
      function close(fd, cb) {
        return fs$close.call(fs, fd, function(err) {
          if (!err) {
            resetQueue();
          }
          if (typeof cb === "function")
            cb.apply(this, arguments);
        });
      }
      Object.defineProperty(close, previousSymbol, {
        value: fs$close
      });
      return close;
    }(fs.close);
    fs.closeSync = function(fs$closeSync) {
      function closeSync(fd) {
        fs$closeSync.apply(fs, arguments);
        resetQueue();
      }
      Object.defineProperty(closeSync, previousSymbol, {
        value: fs$closeSync
      });
      return closeSync;
    }(fs.closeSync);
    if (/\bgfs4\b/i.test(process.env.NODE_DEBUG || "")) {
      process.on("exit", function() {
        debug(fs[gracefulQueue]);
        __require("assert").equal(fs[gracefulQueue].length, 0);
      });
    }
  }
  var queue;
  if (!global[gracefulQueue]) {
    publishQueue(global, fs[gracefulQueue]);
  }
  module.exports = patch(clone(fs));
  if (process.env.TEST_GRACEFUL_FS_GLOBAL_PATCH && !fs.__patched) {
    module.exports = patch(fs);
    fs.__patched = true;
  }
  function patch(fs2) {
    polyfills(fs2);
    fs2.gracefulify = patch;
    fs2.createReadStream = createReadStream;
    fs2.createWriteStream = createWriteStream;
    var fs$readFile = fs2.readFile;
    fs2.readFile = readFile;
    function readFile(path, options, cb) {
      if (typeof options === "function")
        cb = options, options = null;
      return go$readFile(path, options, cb);
      function go$readFile(path2, options2, cb2, startTime) {
        return fs$readFile(path2, options2, function(err) {
          if (err && (err.code === "EMFILE" || err.code === "ENFILE"))
            enqueue([go$readFile, [path2, options2, cb2], err, startTime || Date.now(), Date.now()]);
          else {
            if (typeof cb2 === "function")
              cb2.apply(this, arguments);
          }
        });
      }
    }
    var fs$writeFile = fs2.writeFile;
    fs2.writeFile = writeFile;
    function writeFile(path, data, options, cb) {
      if (typeof options === "function")
        cb = options, options = null;
      return go$writeFile(path, data, options, cb);
      function go$writeFile(path2, data2, options2, cb2, startTime) {
        return fs$writeFile(path2, data2, options2, function(err) {
          if (err && (err.code === "EMFILE" || err.code === "ENFILE"))
            enqueue([go$writeFile, [path2, data2, options2, cb2], err, startTime || Date.now(), Date.now()]);
          else {
            if (typeof cb2 === "function")
              cb2.apply(this, arguments);
          }
        });
      }
    }
    var fs$appendFile = fs2.appendFile;
    if (fs$appendFile)
      fs2.appendFile = appendFile;
    function appendFile(path, data, options, cb) {
      if (typeof options === "function")
        cb = options, options = null;
      return go$appendFile(path, data, options, cb);
      function go$appendFile(path2, data2, options2, cb2, startTime) {
        return fs$appendFile(path2, data2, options2, function(err) {
          if (err && (err.code === "EMFILE" || err.code === "ENFILE"))
            enqueue([go$appendFile, [path2, data2, options2, cb2], err, startTime || Date.now(), Date.now()]);
          else {
            if (typeof cb2 === "function")
              cb2.apply(this, arguments);
          }
        });
      }
    }
    var fs$copyFile = fs2.copyFile;
    if (fs$copyFile)
      fs2.copyFile = copyFile;
    function copyFile(src, dest, flags, cb) {
      if (typeof flags === "function") {
        cb = flags;
        flags = 0;
      }
      return go$copyFile(src, dest, flags, cb);
      function go$copyFile(src2, dest2, flags2, cb2, startTime) {
        return fs$copyFile(src2, dest2, flags2, function(err) {
          if (err && (err.code === "EMFILE" || err.code === "ENFILE"))
            enqueue([go$copyFile, [src2, dest2, flags2, cb2], err, startTime || Date.now(), Date.now()]);
          else {
            if (typeof cb2 === "function")
              cb2.apply(this, arguments);
          }
        });
      }
    }
    var fs$readdir = fs2.readdir;
    fs2.readdir = readdir;
    var noReaddirOptionVersions = /^v[0-5]\./;
    function readdir(path, options, cb) {
      if (typeof options === "function")
        cb = options, options = null;
      var go$readdir = noReaddirOptionVersions.test(process.version) ? function go$readdir2(path2, options2, cb2, startTime) {
        return fs$readdir(path2, fs$readdirCallback(path2, options2, cb2, startTime));
      } : function go$readdir2(path2, options2, cb2, startTime) {
        return fs$readdir(path2, options2, fs$readdirCallback(path2, options2, cb2, startTime));
      };
      return go$readdir(path, options, cb);
      function fs$readdirCallback(path2, options2, cb2, startTime) {
        return function(err, files) {
          if (err && (err.code === "EMFILE" || err.code === "ENFILE"))
            enqueue([
              go$readdir,
              [path2, options2, cb2],
              err,
              startTime || Date.now(),
              Date.now()
            ]);
          else {
            if (files && files.sort)
              files.sort();
            if (typeof cb2 === "function")
              cb2.call(this, err, files);
          }
        };
      }
    }
    if (process.version.substr(0, 4) === "v0.8") {
      var legStreams = legacy(fs2);
      ReadStream = legStreams.ReadStream;
      WriteStream = legStreams.WriteStream;
    }
    var fs$ReadStream = fs2.ReadStream;
    if (fs$ReadStream) {
      ReadStream.prototype = Object.create(fs$ReadStream.prototype);
      ReadStream.prototype.open = ReadStream$open;
    }
    var fs$WriteStream = fs2.WriteStream;
    if (fs$WriteStream) {
      WriteStream.prototype = Object.create(fs$WriteStream.prototype);
      WriteStream.prototype.open = WriteStream$open;
    }
    Object.defineProperty(fs2, "ReadStream", {
      get: function() {
        return ReadStream;
      },
      set: function(val) {
        ReadStream = val;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(fs2, "WriteStream", {
      get: function() {
        return WriteStream;
      },
      set: function(val) {
        WriteStream = val;
      },
      enumerable: true,
      configurable: true
    });
    var FileReadStream = ReadStream;
    Object.defineProperty(fs2, "FileReadStream", {
      get: function() {
        return FileReadStream;
      },
      set: function(val) {
        FileReadStream = val;
      },
      enumerable: true,
      configurable: true
    });
    var FileWriteStream = WriteStream;
    Object.defineProperty(fs2, "FileWriteStream", {
      get: function() {
        return FileWriteStream;
      },
      set: function(val) {
        FileWriteStream = val;
      },
      enumerable: true,
      configurable: true
    });
    function ReadStream(path, options) {
      if (this instanceof ReadStream)
        return fs$ReadStream.apply(this, arguments), this;
      else
        return ReadStream.apply(Object.create(ReadStream.prototype), arguments);
    }
    function ReadStream$open() {
      var that = this;
      open(that.path, that.flags, that.mode, function(err, fd) {
        if (err) {
          if (that.autoClose)
            that.destroy();
          that.emit("error", err);
        } else {
          that.fd = fd;
          that.emit("open", fd);
          that.read();
        }
      });
    }
    function WriteStream(path, options) {
      if (this instanceof WriteStream)
        return fs$WriteStream.apply(this, arguments), this;
      else
        return WriteStream.apply(Object.create(WriteStream.prototype), arguments);
    }
    function WriteStream$open() {
      var that = this;
      open(that.path, that.flags, that.mode, function(err, fd) {
        if (err) {
          that.destroy();
          that.emit("error", err);
        } else {
          that.fd = fd;
          that.emit("open", fd);
        }
      });
    }
    function createReadStream(path, options) {
      return new fs2.ReadStream(path, options);
    }
    function createWriteStream(path, options) {
      return new fs2.WriteStream(path, options);
    }
    var fs$open = fs2.open;
    fs2.open = open;
    function open(path, flags, mode, cb) {
      if (typeof mode === "function")
        cb = mode, mode = null;
      return go$open(path, flags, mode, cb);
      function go$open(path2, flags2, mode2, cb2, startTime) {
        return fs$open(path2, flags2, mode2, function(err, fd) {
          if (err && (err.code === "EMFILE" || err.code === "ENFILE"))
            enqueue([go$open, [path2, flags2, mode2, cb2], err, startTime || Date.now(), Date.now()]);
          else {
            if (typeof cb2 === "function")
              cb2.apply(this, arguments);
          }
        });
      }
    }
    return fs2;
  }
  function enqueue(elem) {
    debug("ENQUEUE", elem[0].name, elem[1]);
    fs[gracefulQueue].push(elem);
    retry();
  }
  var retryTimer;
  function resetQueue() {
    var now = Date.now();
    for (var i = 0;i < fs[gracefulQueue].length; ++i) {
      if (fs[gracefulQueue][i].length > 2) {
        fs[gracefulQueue][i][3] = now;
        fs[gracefulQueue][i][4] = now;
      }
    }
    retry();
  }
  function retry() {
    clearTimeout(retryTimer);
    retryTimer = undefined;
    if (fs[gracefulQueue].length === 0)
      return;
    var elem = fs[gracefulQueue].shift();
    var fn = elem[0];
    var args = elem[1];
    var err = elem[2];
    var startTime = elem[3];
    var lastTime = elem[4];
    if (startTime === undefined) {
      debug("RETRY", fn.name, args);
      fn.apply(null, args);
    } else if (Date.now() - startTime >= 60000) {
      debug("TIMEOUT", fn.name, args);
      var cb = args.pop();
      if (typeof cb === "function")
        cb.call(null, err);
    } else {
      var sinceAttempt = Date.now() - lastTime;
      var sinceStart = Math.max(lastTime - startTime, 1);
      var desiredDelay = Math.min(sinceStart * 1.2, 100);
      if (sinceAttempt >= desiredDelay) {
        debug("RETRY", fn.name, args);
        fn.apply(null, args.concat([startTime]));
      } else {
        fs[gracefulQueue].push(elem);
      }
    }
    if (retryTimer === undefined) {
      retryTimer = setTimeout(retry, 0);
    }
  }
});

// integrations/native-provider/node_modules/retry/lib/retry_operation.js
var require_retry_operation = __commonJS((exports, module) => {
  function RetryOperation(timeouts, options) {
    if (typeof options === "boolean") {
      options = { forever: options };
    }
    this._originalTimeouts = JSON.parse(JSON.stringify(timeouts));
    this._timeouts = timeouts;
    this._options = options || {};
    this._maxRetryTime = options && options.maxRetryTime || Infinity;
    this._fn = null;
    this._errors = [];
    this._attempts = 1;
    this._operationTimeout = null;
    this._operationTimeoutCb = null;
    this._timeout = null;
    this._operationStart = null;
    if (this._options.forever) {
      this._cachedTimeouts = this._timeouts.slice(0);
    }
  }
  module.exports = RetryOperation;
  RetryOperation.prototype.reset = function() {
    this._attempts = 1;
    this._timeouts = this._originalTimeouts;
  };
  RetryOperation.prototype.stop = function() {
    if (this._timeout) {
      clearTimeout(this._timeout);
    }
    this._timeouts = [];
    this._cachedTimeouts = null;
  };
  RetryOperation.prototype.retry = function(err) {
    if (this._timeout) {
      clearTimeout(this._timeout);
    }
    if (!err) {
      return false;
    }
    var currentTime = new Date().getTime();
    if (err && currentTime - this._operationStart >= this._maxRetryTime) {
      this._errors.unshift(new Error("RetryOperation timeout occurred"));
      return false;
    }
    this._errors.push(err);
    var timeout = this._timeouts.shift();
    if (timeout === undefined) {
      if (this._cachedTimeouts) {
        this._errors.splice(this._errors.length - 1, this._errors.length);
        this._timeouts = this._cachedTimeouts.slice(0);
        timeout = this._timeouts.shift();
      } else {
        return false;
      }
    }
    var self = this;
    var timer = setTimeout(function() {
      self._attempts++;
      if (self._operationTimeoutCb) {
        self._timeout = setTimeout(function() {
          self._operationTimeoutCb(self._attempts);
        }, self._operationTimeout);
        if (self._options.unref) {
          self._timeout.unref();
        }
      }
      self._fn(self._attempts);
    }, timeout);
    if (this._options.unref) {
      timer.unref();
    }
    return true;
  };
  RetryOperation.prototype.attempt = function(fn, timeoutOps) {
    this._fn = fn;
    if (timeoutOps) {
      if (timeoutOps.timeout) {
        this._operationTimeout = timeoutOps.timeout;
      }
      if (timeoutOps.cb) {
        this._operationTimeoutCb = timeoutOps.cb;
      }
    }
    var self = this;
    if (this._operationTimeoutCb) {
      this._timeout = setTimeout(function() {
        self._operationTimeoutCb();
      }, self._operationTimeout);
    }
    this._operationStart = new Date().getTime();
    this._fn(this._attempts);
  };
  RetryOperation.prototype.try = function(fn) {
    console.log("Using RetryOperation.try() is deprecated");
    this.attempt(fn);
  };
  RetryOperation.prototype.start = function(fn) {
    console.log("Using RetryOperation.start() is deprecated");
    this.attempt(fn);
  };
  RetryOperation.prototype.start = RetryOperation.prototype.try;
  RetryOperation.prototype.errors = function() {
    return this._errors;
  };
  RetryOperation.prototype.attempts = function() {
    return this._attempts;
  };
  RetryOperation.prototype.mainError = function() {
    if (this._errors.length === 0) {
      return null;
    }
    var counts = {};
    var mainError = null;
    var mainErrorCount = 0;
    for (var i = 0;i < this._errors.length; i++) {
      var error = this._errors[i];
      var message = error.message;
      var count = (counts[message] || 0) + 1;
      counts[message] = count;
      if (count >= mainErrorCount) {
        mainError = error;
        mainErrorCount = count;
      }
    }
    return mainError;
  };
});

// integrations/native-provider/node_modules/retry/lib/retry.js
var require_retry = __commonJS((exports) => {
  var RetryOperation = require_retry_operation();
  exports.operation = function(options) {
    var timeouts = exports.timeouts(options);
    return new RetryOperation(timeouts, {
      forever: options && options.forever,
      unref: options && options.unref,
      maxRetryTime: options && options.maxRetryTime
    });
  };
  exports.timeouts = function(options) {
    if (options instanceof Array) {
      return [].concat(options);
    }
    var opts = {
      retries: 10,
      factor: 2,
      minTimeout: 1 * 1000,
      maxTimeout: Infinity,
      randomize: false
    };
    for (var key in options) {
      opts[key] = options[key];
    }
    if (opts.minTimeout > opts.maxTimeout) {
      throw new Error("minTimeout is greater than maxTimeout");
    }
    var timeouts = [];
    for (var i = 0;i < opts.retries; i++) {
      timeouts.push(this.createTimeout(i, opts));
    }
    if (options && options.forever && !timeouts.length) {
      timeouts.push(this.createTimeout(i, opts));
    }
    timeouts.sort(function(a, b) {
      return a - b;
    });
    return timeouts;
  };
  exports.createTimeout = function(attempt, opts) {
    var random = opts.randomize ? Math.random() + 1 : 1;
    var timeout = Math.round(random * opts.minTimeout * Math.pow(opts.factor, attempt));
    timeout = Math.min(timeout, opts.maxTimeout);
    return timeout;
  };
  exports.wrap = function(obj, options, methods) {
    if (options instanceof Array) {
      methods = options;
      options = null;
    }
    if (!methods) {
      methods = [];
      for (var key in obj) {
        if (typeof obj[key] === "function") {
          methods.push(key);
        }
      }
    }
    for (var i = 0;i < methods.length; i++) {
      var method = methods[i];
      var original = obj[method];
      obj[method] = function retryWrapper(original2) {
        var op = exports.operation(options);
        var args = Array.prototype.slice.call(arguments, 1);
        var callback = args.pop();
        args.push(function(err) {
          if (op.retry(err)) {
            return;
          }
          if (err) {
            arguments[0] = op.mainError();
          }
          callback.apply(this, arguments);
        });
        op.attempt(function() {
          original2.apply(obj, args);
        });
      }.bind(obj, original);
      obj[method].options = options;
    }
  };
});

// integrations/native-provider/node_modules/signal-exit/signals.js
var require_signals = __commonJS((exports, module) => {
  module.exports = [
    "SIGABRT",
    "SIGALRM",
    "SIGHUP",
    "SIGINT",
    "SIGTERM"
  ];
  if (process.platform !== "win32") {
    module.exports.push("SIGVTALRM", "SIGXCPU", "SIGXFSZ", "SIGUSR2", "SIGTRAP", "SIGSYS", "SIGQUIT", "SIGIOT");
  }
  if (process.platform === "linux") {
    module.exports.push("SIGIO", "SIGPOLL", "SIGPWR", "SIGSTKFLT", "SIGUNUSED");
  }
});

// integrations/native-provider/node_modules/signal-exit/index.js
var require_signal_exit = __commonJS((exports, module) => {
  var process2 = global.process;
  var processOk = function(process3) {
    return process3 && typeof process3 === "object" && typeof process3.removeListener === "function" && typeof process3.emit === "function" && typeof process3.reallyExit === "function" && typeof process3.listeners === "function" && typeof process3.kill === "function" && typeof process3.pid === "number" && typeof process3.on === "function";
  };
  if (!processOk(process2)) {
    module.exports = function() {
      return function() {};
    };
  } else {
    assert = __require("assert");
    signals = require_signals();
    isWin = /^win/i.test(process2.platform);
    EE = __require("events");
    if (typeof EE !== "function") {
      EE = EE.EventEmitter;
    }
    if (process2.__signal_exit_emitter__) {
      emitter = process2.__signal_exit_emitter__;
    } else {
      emitter = process2.__signal_exit_emitter__ = new EE;
      emitter.count = 0;
      emitter.emitted = {};
    }
    if (!emitter.infinite) {
      emitter.setMaxListeners(Infinity);
      emitter.infinite = true;
    }
    module.exports = function(cb, opts) {
      if (!processOk(global.process)) {
        return function() {};
      }
      assert.equal(typeof cb, "function", "a callback must be provided for exit handler");
      if (loaded === false) {
        load();
      }
      var ev = "exit";
      if (opts && opts.alwaysLast) {
        ev = "afterexit";
      }
      var remove = function() {
        emitter.removeListener(ev, cb);
        if (emitter.listeners("exit").length === 0 && emitter.listeners("afterexit").length === 0) {
          unload();
        }
      };
      emitter.on(ev, cb);
      return remove;
    };
    unload = function unload2() {
      if (!loaded || !processOk(global.process)) {
        return;
      }
      loaded = false;
      signals.forEach(function(sig) {
        try {
          process2.removeListener(sig, sigListeners[sig]);
        } catch (er) {}
      });
      process2.emit = originalProcessEmit;
      process2.reallyExit = originalProcessReallyExit;
      emitter.count -= 1;
    };
    module.exports.unload = unload;
    emit = function emit2(event, code, signal) {
      if (emitter.emitted[event]) {
        return;
      }
      emitter.emitted[event] = true;
      emitter.emit(event, code, signal);
    };
    sigListeners = {};
    signals.forEach(function(sig) {
      sigListeners[sig] = function listener() {
        if (!processOk(global.process)) {
          return;
        }
        var listeners = process2.listeners(sig);
        if (listeners.length === emitter.count) {
          unload();
          emit("exit", null, sig);
          emit("afterexit", null, sig);
          if (isWin && sig === "SIGHUP") {
            sig = "SIGINT";
          }
          process2.kill(process2.pid, sig);
        }
      };
    });
    module.exports.signals = function() {
      return signals;
    };
    loaded = false;
    load = function load2() {
      if (loaded || !processOk(global.process)) {
        return;
      }
      loaded = true;
      emitter.count += 1;
      signals = signals.filter(function(sig) {
        try {
          process2.on(sig, sigListeners[sig]);
          return true;
        } catch (er) {
          return false;
        }
      });
      process2.emit = processEmit;
      process2.reallyExit = processReallyExit;
    };
    module.exports.load = load;
    originalProcessReallyExit = process2.reallyExit;
    processReallyExit = function processReallyExit2(code) {
      if (!processOk(global.process)) {
        return;
      }
      process2.exitCode = code || 0;
      emit("exit", process2.exitCode, null);
      emit("afterexit", process2.exitCode, null);
      originalProcessReallyExit.call(process2, process2.exitCode);
    };
    originalProcessEmit = process2.emit;
    processEmit = function processEmit2(ev, arg) {
      if (ev === "exit" && processOk(global.process)) {
        if (arg !== undefined) {
          process2.exitCode = arg;
        }
        var ret = originalProcessEmit.apply(this, arguments);
        emit("exit", process2.exitCode, null);
        emit("afterexit", process2.exitCode, null);
        return ret;
      } else {
        return originalProcessEmit.apply(this, arguments);
      }
    };
  }
  var assert;
  var signals;
  var isWin;
  var EE;
  var emitter;
  var unload;
  var emit;
  var sigListeners;
  var loaded;
  var load;
  var originalProcessReallyExit;
  var processReallyExit;
  var originalProcessEmit;
  var processEmit;
});

// integrations/native-provider/node_modules/proper-lockfile/lib/mtime-precision.js
var require_mtime_precision = __commonJS((exports, module) => {
  var cacheSymbol = Symbol();
  function probe(file, fs, callback) {
    const cachedPrecision = fs[cacheSymbol];
    if (cachedPrecision) {
      return fs.stat(file, (err, stat) => {
        if (err) {
          return callback(err);
        }
        callback(null, stat.mtime, cachedPrecision);
      });
    }
    const mtime = new Date(Math.ceil(Date.now() / 1000) * 1000 + 5);
    fs.utimes(file, mtime, mtime, (err) => {
      if (err) {
        return callback(err);
      }
      fs.stat(file, (err2, stat) => {
        if (err2) {
          return callback(err2);
        }
        const precision = stat.mtime.getTime() % 1000 === 0 ? "s" : "ms";
        Object.defineProperty(fs, cacheSymbol, { value: precision });
        callback(null, stat.mtime, precision);
      });
    });
  }
  function getMtime(precision) {
    let now = Date.now();
    if (precision === "s") {
      now = Math.ceil(now / 1000) * 1000;
    }
    return new Date(now);
  }
  exports.probe = probe;
  exports.getMtime = getMtime;
});

// integrations/native-provider/node_modules/proper-lockfile/lib/lockfile.js
var require_lockfile = __commonJS((exports, module) => {
  var path = __require("path");
  var fs = require_graceful_fs();
  var retry = require_retry();
  var onExit = require_signal_exit();
  var mtimePrecision = require_mtime_precision();
  var locks = {};
  function getLockFile(file, options) {
    return options.lockfilePath || `${file}.lock`;
  }
  function resolveCanonicalPath(file, options, callback) {
    if (!options.realpath) {
      return callback(null, path.resolve(file));
    }
    options.fs.realpath(file, callback);
  }
  function acquireLock(file, options, callback) {
    const lockfilePath = getLockFile(file, options);
    options.fs.mkdir(lockfilePath, (err) => {
      if (!err) {
        return mtimePrecision.probe(lockfilePath, options.fs, (err2, mtime, mtimePrecision2) => {
          if (err2) {
            options.fs.rmdir(lockfilePath, () => {});
            return callback(err2);
          }
          callback(null, mtime, mtimePrecision2);
        });
      }
      if (err.code !== "EEXIST") {
        return callback(err);
      }
      if (options.stale <= 0) {
        return callback(Object.assign(new Error("Lock file is already being held"), { code: "ELOCKED", file }));
      }
      options.fs.stat(lockfilePath, (err2, stat) => {
        if (err2) {
          if (err2.code === "ENOENT") {
            return acquireLock(file, { ...options, stale: 0 }, callback);
          }
          return callback(err2);
        }
        if (!isLockStale(stat, options)) {
          return callback(Object.assign(new Error("Lock file is already being held"), { code: "ELOCKED", file }));
        }
        removeLock(file, options, (err3) => {
          if (err3) {
            return callback(err3);
          }
          acquireLock(file, { ...options, stale: 0 }, callback);
        });
      });
    });
  }
  function isLockStale(stat, options) {
    return stat.mtime.getTime() < Date.now() - options.stale;
  }
  function removeLock(file, options, callback) {
    options.fs.rmdir(getLockFile(file, options), (err) => {
      if (err && err.code !== "ENOENT") {
        return callback(err);
      }
      callback();
    });
  }
  function updateLock(file, options) {
    const lock2 = locks[file];
    if (lock2.updateTimeout) {
      return;
    }
    lock2.updateDelay = lock2.updateDelay || options.update;
    lock2.updateTimeout = setTimeout(() => {
      lock2.updateTimeout = null;
      options.fs.stat(lock2.lockfilePath, (err, stat) => {
        const isOverThreshold = lock2.lastUpdate + options.stale < Date.now();
        if (err) {
          if (err.code === "ENOENT" || isOverThreshold) {
            return setLockAsCompromised(file, lock2, Object.assign(err, { code: "ECOMPROMISED" }));
          }
          lock2.updateDelay = 1000;
          return updateLock(file, options);
        }
        const isMtimeOurs = lock2.mtime.getTime() === stat.mtime.getTime();
        if (!isMtimeOurs) {
          return setLockAsCompromised(file, lock2, Object.assign(new Error("Unable to update lock within the stale threshold"), { code: "ECOMPROMISED" }));
        }
        const mtime = mtimePrecision.getMtime(lock2.mtimePrecision);
        options.fs.utimes(lock2.lockfilePath, mtime, mtime, (err2) => {
          const isOverThreshold2 = lock2.lastUpdate + options.stale < Date.now();
          if (lock2.released) {
            return;
          }
          if (err2) {
            if (err2.code === "ENOENT" || isOverThreshold2) {
              return setLockAsCompromised(file, lock2, Object.assign(err2, { code: "ECOMPROMISED" }));
            }
            lock2.updateDelay = 1000;
            return updateLock(file, options);
          }
          lock2.mtime = mtime;
          lock2.lastUpdate = Date.now();
          lock2.updateDelay = null;
          updateLock(file, options);
        });
      });
    }, lock2.updateDelay);
    if (lock2.updateTimeout.unref) {
      lock2.updateTimeout.unref();
    }
  }
  function setLockAsCompromised(file, lock2, err) {
    lock2.released = true;
    if (lock2.updateTimeout) {
      clearTimeout(lock2.updateTimeout);
    }
    if (locks[file] === lock2) {
      delete locks[file];
    }
    lock2.options.onCompromised(err);
  }
  function lock(file, options, callback) {
    options = {
      stale: 1e4,
      update: null,
      realpath: true,
      retries: 0,
      fs,
      onCompromised: (err) => {
        throw err;
      },
      ...options
    };
    options.retries = options.retries || 0;
    options.retries = typeof options.retries === "number" ? { retries: options.retries } : options.retries;
    options.stale = Math.max(options.stale || 0, 2000);
    options.update = options.update == null ? options.stale / 2 : options.update || 0;
    options.update = Math.max(Math.min(options.update, options.stale / 2), 1000);
    resolveCanonicalPath(file, options, (err, file2) => {
      if (err) {
        return callback(err);
      }
      const operation = retry.operation(options.retries);
      operation.attempt(() => {
        acquireLock(file2, options, (err2, mtime, mtimePrecision2) => {
          if (operation.retry(err2)) {
            return;
          }
          if (err2) {
            return callback(operation.mainError());
          }
          const lock2 = locks[file2] = {
            lockfilePath: getLockFile(file2, options),
            mtime,
            mtimePrecision: mtimePrecision2,
            options,
            lastUpdate: Date.now()
          };
          updateLock(file2, options);
          callback(null, (releasedCallback) => {
            if (lock2.released) {
              return releasedCallback && releasedCallback(Object.assign(new Error("Lock is already released"), { code: "ERELEASED" }));
            }
            unlock(file2, { ...options, realpath: false }, releasedCallback);
          });
        });
      });
    });
  }
  function unlock(file, options, callback) {
    options = {
      fs,
      realpath: true,
      ...options
    };
    resolveCanonicalPath(file, options, (err, file2) => {
      if (err) {
        return callback(err);
      }
      const lock2 = locks[file2];
      if (!lock2) {
        return callback(Object.assign(new Error("Lock is not acquired/owned by you"), { code: "ENOTACQUIRED" }));
      }
      lock2.updateTimeout && clearTimeout(lock2.updateTimeout);
      lock2.released = true;
      delete locks[file2];
      removeLock(file2, options, callback);
    });
  }
  function check(file, options, callback) {
    options = {
      stale: 1e4,
      realpath: true,
      fs,
      ...options
    };
    options.stale = Math.max(options.stale || 0, 2000);
    resolveCanonicalPath(file, options, (err, file2) => {
      if (err) {
        return callback(err);
      }
      options.fs.stat(getLockFile(file2, options), (err2, stat) => {
        if (err2) {
          return err2.code === "ENOENT" ? callback(null, false) : callback(err2);
        }
        return callback(null, !isLockStale(stat, options));
      });
    });
  }
  function getLocks() {
    return locks;
  }
  onExit(() => {
    for (const file in locks) {
      const options = locks[file].options;
      try {
        options.fs.rmdirSync(getLockFile(file, options));
      } catch (e) {}
    }
  });
  exports.lock = lock;
  exports.unlock = unlock;
  exports.check = check;
  exports.getLocks = getLocks;
});

// integrations/native-provider/node_modules/proper-lockfile/lib/adapter.js
var require_adapter = __commonJS((exports, module) => {
  var fs = require_graceful_fs();
  function createSyncFs(fs2) {
    const methods = ["mkdir", "realpath", "stat", "rmdir", "utimes"];
    const newFs = { ...fs2 };
    methods.forEach((method) => {
      newFs[method] = (...args) => {
        const callback = args.pop();
        let ret;
        try {
          ret = fs2[`${method}Sync`](...args);
        } catch (err) {
          return callback(err);
        }
        callback(null, ret);
      };
    });
    return newFs;
  }
  function toPromise(method) {
    return (...args) => new Promise((resolve, reject) => {
      args.push((err, result) => {
        if (err) {
          reject(err);
        } else {
          resolve(result);
        }
      });
      method(...args);
    });
  }
  function toSync(method) {
    return (...args) => {
      let err;
      let result;
      args.push((_err, _result) => {
        err = _err;
        result = _result;
      });
      method(...args);
      if (err) {
        throw err;
      }
      return result;
    };
  }
  function toSyncOptions(options) {
    options = { ...options };
    options.fs = createSyncFs(options.fs || fs);
    if (typeof options.retries === "number" && options.retries > 0 || options.retries && typeof options.retries.retries === "number" && options.retries.retries > 0) {
      throw Object.assign(new Error("Cannot use retries with the sync api"), { code: "ESYNC" });
    }
    return options;
  }
  module.exports = {
    toPromise,
    toSync,
    toSyncOptions
  };
});

// integrations/native-provider/node_modules/proper-lockfile/index.js
var require_proper_lockfile = __commonJS((exports, module) => {
  var lockfile = require_lockfile();
  var { toPromise, toSync, toSyncOptions } = require_adapter();
  async function lock(file, options) {
    const release = await toPromise(lockfile.lock)(file, options);
    return toPromise(release);
  }
  function lockSync(file, options) {
    const release = toSync(lockfile.lock)(file, toSyncOptions(options));
    return toSync(release);
  }
  function unlock(file, options) {
    return toPromise(lockfile.unlock)(file, options);
  }
  function unlockSync(file, options) {
    return toSync(lockfile.unlock)(file, toSyncOptions(options));
  }
  function check(file, options) {
    return toPromise(lockfile.check)(file, options);
  }
  function checkSync(file, options) {
    return toSync(lockfile.check)(file, toSyncOptions(options));
  }
  module.exports = lock;
  module.exports.lock = lock;
  module.exports.unlock = unlock;
  module.exports.lockSync = lockSync;
  module.exports.unlockSync = unlockSync;
  module.exports.check = check;
  module.exports.checkSync = checkSync;
});

// integrations/native-provider/cursor/errors.mjs
function safeError(error2) {
  return error2 instanceof CursorProviderError ? error2 : fail("transport_error", "Cursor transport failed.");
}
function checkSignal(signal) {
  if (signal?.aborted)
    throw aborted();
}
function onAbort(signal, fn) {
  if (!signal)
    return () => {};
  if (signal.aborted) {
    fn();
    return () => {};
  }
  signal.addEventListener("abort", fn, { once: true });
  return () => signal.removeEventListener("abort", fn);
}
function interruptible(promise, signal) {
  return new Promise((resolve2, reject) => {
    let off = () => {};
    off = onAbort(signal, () => reject(aborted()));
    Promise.resolve(promise).then(resolve2, reject).finally(() => off());
  });
}
function delay(ms, signal) {
  return new Promise((resolve2, reject) => {
    checkSignal(signal);
    const timer = setTimeout(() => {
      off();
      resolve2();
    }, ms);
    const off = onAbort(signal, () => {
      clearTimeout(timer);
      reject(aborted());
    });
  });
}
var CursorProviderError, fail = (code, message, status) => new CursorProviderError(code, message, status), aborted = () => fail("cancelled", "Cursor request cancelled.", 499), errorBody = (error2) => {
  const e = safeError(error2);
  return { error: { type: "cursor_provider_error", code: e.code, message: e.message } };
};
var init_errors = __esm(() => {
  CursorProviderError = class CursorProviderError extends Error {
    constructor(code, message, status = 502) {
      super(message);
      this.name = "CursorProviderError";
      this.code = code;
      this.status = status;
    }
  };
});

// integrations/native-provider/cursor/content.mjs
function inlineImage(part) {
  if (!object(part.image_url) || Object.keys(part).some((k) => !["type", "image_url"].includes(k)) || Object.keys(part.image_url).some((k) => !["url", "detail"].includes(k)) || ![undefined, "auto"].includes(part.image_url.detail) || typeof part.image_url.url !== "string")
    throw unsupported();
  const match = /^data:(image\/(?:png|jpeg|gif|webp));base64,([A-Za-z0-9+/]+={0,2})$/.exec(part.image_url.url);
  if (!match || match[2].length % 4 !== 0)
    throw unsupported();
  const data = Buffer.from(match[2], "base64");
  if (!data.length || data.toString("base64") !== match[2])
    throw unsupported();
  const mimeType = match[1];
  const valid = mimeType === "image/png" ? data.length >= 24 && data.subarray(0, 8).equals(Buffer.from("89504e470d0a1a0a", "hex")) && data.readUInt32BE(8) === 13 && data.toString("ascii", 12, 16) === "IHDR" && data.readUInt32BE(16) > 0 && data.readUInt32BE(20) > 0 : mimeType === "image/jpeg" ? data.length >= 4 && data[0] === 255 && data[1] === 216 && data[2] === 255 && data.at(-2) === 255 && data.at(-1) === 217 : mimeType === "image/gif" ? data.length >= 14 && ["GIF87a", "GIF89a"].includes(data.toString("ascii", 0, 6)) && data.readUInt16LE(6) > 0 && data.readUInt16LE(8) > 0 && data.at(-1) === 59 : data.length >= 20 && data.toString("ascii", 0, 4) === "RIFF" && data.toString("ascii", 8, 12) === "WEBP" && data.readUInt32LE(4) === data.length - 8;
  if (!valid)
    throw unsupported();
  return { type: "image", data, mimeType };
}
function messageParts(message) {
  const value = message.content;
  let parts;
  if (typeof value === "string")
    parts = [textPart(value)];
  else if ((value === null || value === undefined) && message.role === "assistant")
    parts = [];
  else if (Array.isArray(value))
    parts = value.map((part) => {
      if (message.role === "tool" && (!object(part) || part.type === undefined))
        return textPart(JSON.stringify(part));
      if (!object(part))
        throw invalid();
      if (part.type === "image_url") {
        if (!["user", "tool"].includes(message.role))
          throw unsupported();
        return inlineImage(part);
      }
      if (part.type !== "text" || typeof part.text !== "string")
        throw unsupported();
      return textPart(Object.keys(part).some((k) => !["type", "text"].includes(k)) ? JSON.stringify(part) : part.text);
    });
  else if (message.role === "tool" && value !== undefined)
    parts = [textPart(JSON.stringify(value))];
  else
    throw invalid();
  const standard = ["role", "content", "tool_calls", ...message.role === "tool" ? ["tool_call_id", "is_error"] : []];
  const metadata = Object.fromEntries(Object.entries(message).filter(([k]) => !standard.includes(k)));
  if (Object.keys(metadata).length)
    parts.push(textPart(JSON.stringify({ polycode_message_metadata: metadata })));
  return parts;
}
function toolParts(message) {
  const parts = messageParts(message);
  if (parts.some((p) => p.type === "image"))
    return parts;
  const extra = Object.keys(message).some((k) => !["role", "tool_call_id", "content", "is_error"].includes(k));
  return [textPart(extra ? JSON.stringify(message) : typeof message.content === "string" ? message.content : JSON.stringify(message.content))];
}
function validateMessages(messages) {
  const calls = new Map, pending = new Set;
  let images = 0;
  for (const message of messages) {
    if (!object(message) || !["system", "developer", "user", "assistant", "tool"].includes(message.role))
      throw invalid();
    if (!Object.hasOwn(message, "content") && !(message.role === "assistant" && message.tool_calls))
      throw invalid();
    if (message.is_error !== undefined && (message.role !== "tool" || typeof message.is_error !== "boolean"))
      throw invalid();
    images += messageParts(message).filter((p) => p.type === "image").length;
    if (images > 32)
      throw fail("size_limit", "Too many inline images in this request.", 413);
    if (message.role === "user" && pending.size)
      throw invalid();
    if (message.tool_calls !== undefined) {
      if (message.role !== "assistant" || !Array.isArray(message.tool_calls) || !message.tool_calls.length)
        throw invalid();
      for (const call of message.tool_calls) {
        if (!object(call) || call.type !== "function" || typeof call.id !== "string" || !call.id || call.id.length > 512 || calls.has(call.id) || !object(call.function) || typeof call.function.name !== "string" || !call.function.name || call.function.name.length > 512 || typeof call.function.arguments !== "string")
          throw invalid();
        if (Object.keys(call).some((k) => !["id", "type", "function"].includes(k)) || Object.keys(call.function).some((k) => !["name", "arguments"].includes(k)))
          throw invalid();
        try {
          JSON.parse(call.function.arguments);
        } catch {
          throw invalid();
        }
        calls.set(call.id, call.function.name);
        pending.add(call.id);
      }
    }
    if (message.role === "tool") {
      if (typeof message.tool_call_id !== "string" || !message.tool_call_id)
        throw invalid();
      if (!pending.delete(message.tool_call_id) || message.name !== undefined && message.name !== calls.get(message.tool_call_id)) {
        throw fail("continuation_mismatch", "Tool result does not match an earlier unresolved call in this transcript.", 409);
      }
    }
  }
}
var object = (x) => x !== null && typeof x === "object" && !Array.isArray(x), invalid = () => fail("invalid_request", "Invalid or unsupported Chat Completions message.", 400), unsupported = () => fail("unsupported_content", "Unsupported message content or image option; only inline PNG/JPEG/GIF/WebP data URLs are supported.", 400), textPart = (text2) => ({ type: "text", text: text2 });
var init_content = __esm(() => {
  init_errors();
});

// integrations/native-provider/cursor/protocol.mjs
import { createHash as createHash3 } from "crypto";
function concat(...arrays) {
  const size = arrays.reduce((n, a) => n + a.length, 0);
  if (size > MAX_FRAME)
    throw fail("size_limit", "Cursor protocol size limit exceeded.");
  const out = new Uint8Array(size);
  let offset = 0;
  for (const a of arrays) {
    out.set(a, offset);
    offset += a.length;
  }
  return out;
}
function varint(value) {
  let n = BigInt(value);
  if (n < 0n || n > 0xffffffffffffffffn)
    throw malformed();
  const out = [];
  do {
    out.push(Number(n & 127n) | (n > 127n ? 128 : 0));
    n >>= 7n;
  } while (n);
  return Uint8Array.from(out);
}
function fields(data) {
  let offset = 0;
  const readVarint = () => {
    let n = 0n;
    for (let i = 0;i < 10; i++) {
      if (offset >= data.length)
        throw malformed();
      const b = data[offset++];
      if (i === 9 && b > 1)
        throw malformed();
      n |= BigInt(b & 127) << BigInt(i * 7);
      if (!(b & 128))
        return n;
    }
    throw malformed();
  };
  const result = [];
  while (offset < data.length) {
    if (result.length >= 1e5)
      throw malformed();
    const tag = readVarint();
    const id = Number(tag >> 3n), wire = Number(tag & 7n);
    if (!id || id > 536870911)
      throw malformed();
    let value;
    if (wire === 0)
      value = readVarint();
    else {
      const size = wire === 2 ? Number(readVarint()) : wire === 1 ? 8 : wire === 5 ? 4 : -1;
      if (size < 0 || !Number.isSafeInteger(size) || size > MAX_FRAME || offset + size > data.length)
        throw malformed();
      value = data.slice(offset, offset + size);
      offset += size;
    }
    result.push({ id, wire, value });
  }
  return result;
}
function one(fs, id, wire = 2, required = true) {
  const matches = fs.filter((f) => f.id === id);
  if (matches.length > 1 || required && !matches.length || matches.length && matches[0].wire !== wire)
    throw malformed();
  return matches[0]?.value;
}
function only(fs, allowed) {
  if (fs.some((f) => !allowed.includes(f.id)))
    throw fail("unsupported_protocol", "Unsupported Cursor protocol request; nothing was executed.");
}
function encodeValue(value, depth = 0) {
  if (depth > 64)
    throw malformed();
  if (value === null)
    return uint(1, 0);
  if (typeof value === "boolean")
    return uint(4, value ? 1 : 0);
  if (typeof value === "string")
    return string(3, value);
  if (typeof value === "number" && Number.isFinite(value)) {
    const data = new Uint8Array(8);
    new DataView(data.buffer).setFloat64(0, value, true);
    return concat(varint(17), data);
  }
  if (Array.isArray(value))
    return bytes(6, concat(...value.map((v) => bytes(1, encodeValue(v, depth + 1)))));
  if (value && typeof value === "object")
    return bytes(5, concat(...Object.entries(value).map(([k, v]) => bytes(1, concat(string(1, k), bytes(2, encodeValue(v, depth + 1)))))));
  throw malformed();
}
function decodeMap(data, depth = 0, entryId = 1) {
  const fs = fields(data);
  only(fs, [entryId]);
  const result = {};
  for (const f of fs) {
    if (f.wire !== 2)
      throw malformed();
    const entry = fields(f.value);
    only(entry, [1, 2]);
    const key = text2(one(entry, 1, 2, false) ?? empty);
    if (Object.hasOwn(result, key))
      throw malformed();
    Object.defineProperty(result, key, { value: decodeValue(one(entry, 2), depth + 1), enumerable: true });
  }
  return result;
}
function decodeValue(data, depth = 0) {
  if (depth > 64)
    throw malformed();
  const fs = fields(data);
  if (fs.length !== 1)
    throw malformed();
  const f = fs[0];
  if (f.id === 1 && f.wire === 0 && f.value === 0n)
    return null;
  if (f.id === 2 && f.wire === 1) {
    const n = new DataView(f.value.buffer, f.value.byteOffset, 8).getFloat64(0, true);
    if (!Number.isFinite(n))
      throw malformed();
    return n;
  }
  if (f.id === 3 && f.wire === 2)
    return text2(f.value);
  if (f.id === 4 && f.wire === 0 && (f.value === 0n || f.value === 1n))
    return f.value === 1n;
  if (f.id === 5 && f.wire === 2)
    return decodeMap(f.value, depth);
  if (f.id === 6 && f.wire === 2) {
    const items = fields(f.value);
    only(items, [1]);
    return items.map((item) => {
      if (item.wire !== 2)
        throw malformed();
      return decodeValue(item.value, depth + 1);
    });
  }
  throw malformed();
}
function envelope(data, flags = 0) {
  if (data.length > MAX_FRAME - 5)
    throw malformed();
  const header = new Uint8Array(5);
  header[0] = flags;
  new DataView(header.buffer).setUint32(1, data.length);
  return concat(header, data);
}
function checksum(token, now = Date.now()) {
  const date = new Date(now);
  date.setMinutes(30 * Math.floor(date.getMinutes() / 30), 0, 0);
  let timestamp = Math.floor(date.getTime() / 1e6);
  const data = Buffer.alloc(6);
  for (let i = 5;i >= 0; i--) {
    data[i] = timestamp & 255;
    timestamp = Math.floor(timestamp / 256);
  }
  let t = 165;
  for (let i = 0;i < data.length; i++) {
    data[i] = (data[i] ^ t) + i & 255;
    t = data[i];
  }
  const hash = (s) => createHash3("sha256").update(s).digest("hex").slice(0, 8);
  const salt = token.split(".")[1];
  return `${data.toString("base64url")}${salt ? hash(salt) : "00000000"}/${hash(token)}`;
}
function mcpDefinition(tool) {
  const f = tool.function;
  return concat(string(1, `${MCP_PROVIDER}-${f.name}`), string(2, f.description ?? ""), bytes(3, encodeValue(f.parameters ?? { type: "object", properties: {} })), string(4, MCP_PROVIDER), string(5, f.name));
}
function conversationHistory(messages) {
  const calls = new Map, history = [];
  for (const message of messages) {
    if (["system", "developer"].includes(message.role))
      continue;
    let data;
    if (message.role === "tool") {
      data = bytes(3, concat(string(1, message.tool_call_id), string(2, calls.get(message.tool_call_id)), ...toolParts(message).map((part) => bytes(3, historyContent(part))), ...message.is_error === undefined ? [] : [uint(4, message.is_error ? 1 : 0)]));
    } else {
      const content = messageParts(message).map((part) => bytes(1, historyContent(part)));
      for (const call of message.tool_calls ?? []) {
        calls.set(call.id, call.function.name);
        content.push(bytes(1, bytes(4, concat(string(1, call.id), string(2, call.function.name), string(3, call.function.arguments)))));
      }
      data = bytes(message.role === "user" ? 1 : 2, concat(...content));
    }
    history.push(bytes(1, data));
  }
  return concat(...history);
}
function userRule(message, index) {
  return concat(string(1, `/polycode-virtual/${message.role}-${index}.mdc`), string(2, messageParts(message).map((p) => p.text).join(`
`)), bytes(3, bytes(1, empty)), uint(4, 2));
}
function runMessage(body, conversationId, messageId) {
  const tools = (body.tools ?? []).map(mcpDefinition);
  const instructions = "Only request the explicitly supplied MCP tools. Polycode owns all execution and permissions. " + "No built-in tools, filesystem, shell, web, subagents, or mode switches are available. " + "The /polycode-virtual environment is transport metadata, not the native workspace. " + "For MCP file and shell tools use relative paths in the native workspace, or exact absolute paths provided by the caller. Never prepend /polycode-virtual to tool arguments.";
  const rules = body.messages.flatMap((m, i) => ["system", "developer"].includes(m.role) ? [bytes(2, userRule(m, i))] : []);
  const context = concat(...rules, bytes(4, concat(string(1, "Polycode model transport"), string(2, "/polycode-virtual"), string(10, "UTC"), string(11, "/polycode-virtual"))), ...tools.map((t) => bytes(7, t)), bytes(14, concat(string(1, MCP_PROVIDER), string(2, instructions), string(3, MCP_PROVIDER))));
  const parts = messageParts(body.messages.at(-1));
  const images = parts.filter((p) => p.type === "image").map((p, i) => bytes(1, concat(string(2, `${messageId}-image-${i}`), string(7, p.mimeType), bytes(8, p.data))));
  const user = concat(string(1, parts.filter((p) => p.type === "text").map((p) => p.text).join(`
`)), string(2, messageId), ...images.length ? [bytes(3, concat(...images))] : [], uint(4, 1));
  const history = conversationHistory(body.messages.slice(0, -1));
  const action = bytes(1, concat(bytes(1, user), bytes(2, context), ...history.length ? [bytes(7, history)] : []));
  return bytes(1, concat(bytes(1, empty), bytes(2, action), bytes(3, string(1, body.model)), bytes(4, concat(...tools.map((t) => bytes(1, t)))), string(5, conversationId)));
}
function turnUsage(data) {
  const fs = fields(data);
  only(fs, [1, 2, 3, 4, 5]);
  const counts = [1, 2, 3, 4, 5].map((id) => {
    const value = one(fs, id, 0, false);
    return value === undefined ? undefined : number(value);
  });
  if (counts.every((n) => n === undefined))
    return;
  const [input, output, read, write, reasoning] = counts, usage = {};
  if (input !== undefined)
    usage.prompt_tokens = input;
  if (output !== undefined)
    usage.completion_tokens = output;
  if (input !== undefined && output !== undefined)
    usage.total_tokens = number(BigInt(input) + BigInt(output));
  if (read !== undefined || write !== undefined)
    usage.prompt_tokens_details = {
      ...read === undefined ? {} : { cached_tokens: read },
      ...write === undefined ? {} : { cache_write_tokens: write }
    };
  if (reasoning !== undefined)
    usage.completion_tokens_details = { reasoning_tokens: reasoning };
  return usage;
}
function parseExec(data) {
  const fs = fields(data);
  if (fs.some((f) => ![1, 11, 15, 19, 55].includes(f.id)) || !fs.some((f) => f.id === 11)) {
    throw fail("unsupported_builtin", "Cursor requested a non-MCP/built-in operation; denied without execution.");
  }
  const id = number(one(fs, 1, 0, false) ?? 0n);
  const execId = one(fs, 15, 2, false);
  one(fs, 19, 2, false);
  const acceptsHookContext = one(fs, 55, 0, false);
  if (acceptsHookContext !== undefined && acceptsHookContext > 1n)
    throw malformed();
  const args = fields(one(fs, 11));
  only(args, [1, 2, 3, 4, 5, 9]);
  const name = text2(one(args, 1));
  const toolCallId = text2(one(args, 3));
  const providerIdentifier = text2(one(args, 4));
  const toolName = text2(one(args, 5));
  const serverIdentifier = one(args, 9, 2, false);
  if (serverIdentifier && text2(serverIdentifier) !== MCP_PROVIDER)
    throw malformed();
  if (!toolCallId || toolCallId.length > 512 || !toolName || providerIdentifier !== MCP_PROVIDER || name !== `${MCP_PROVIDER}-${toolName}`)
    throw malformed();
  const argData = concat(...args.filter((f) => f.id === 2).map((f) => {
    if (f.wire !== 2)
      throw malformed();
    return bytes(1, f.value);
  }));
  return { id, execId: execId ? text2(execId) : undefined, name, toolCallId, providerIdentifier, toolName, args: decodeMap(argData) };
}
function toolResult(exec, message) {
  const content = toolParts(message).map((part) => bytes(1, part.type === "text" ? bytes(1, string(1, part.text)) : bytes(2, concat(bytes(1, part.data), string(2, part.mimeType)))));
  const success = concat(...content, uint(2, message.is_error === true ? 1 : 0));
  return bytes(2, concat(uint(1, exec.id), ...exec.execId === undefined ? [] : [string(15, exec.execId)], bytes(11, bytes(1, success))));
}
var MAX_FRAME, MCP_PROVIDER = "polycode-native", empty, encoder, decoder, malformed = () => fail("invalid_protocol", "Malformed or unsupported Cursor protocol data."), text2 = (bytes) => {
  try {
    return decoder.decode(bytes);
  } catch {
    throw malformed();
  }
}, uint = (id, n) => concat(varint(id * 8), varint(n)), bytes = (id, data) => concat(varint(id * 8 + 2), varint(data.length), data), string = (id, value) => bytes(id, encoder.encode(value)), number = (value) => {
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n < 0)
    throw malformed();
  return n;
}, historyContent = (part) => part.type === "text" ? bytes(1, string(1, part.text)) : bytes(2, concat(string(1, part.data.toString("base64")), string(2, part.mimeType))), bidiRequest = (id) => string(1, id), appendRequest = (id, seq, data) => concat(string(1, Buffer.from(data).toString("hex")), bytes(2, bidiRequest(id)), uint(3, seq)), toolClose = (exec) => bytes(5, bytes(1, uint(1, exec.id)));
var init_protocol = __esm(() => {
  init_errors();
  init_content();
  MAX_FRAME = 8 * 1024 * 1024;
  empty = new Uint8Array;
  encoder = new TextEncoder;
  decoder = new TextDecoder("utf-8", { fatal: true });
});

// integrations/native-provider/cursor/transport.mjs
function headers2(token, requestId, now) {
  return {
    authorization: `Bearer ${token}`,
    "content-type": "application/grpc-web+proto",
    "user-agent": "connect-es/1.4.0",
    "x-cursor-checksum": checksum(token, now),
    "x-cursor-client-version": "cli-2025.11.25-d5b3271",
    "x-cursor-client-type": "cli",
    "x-cursor-timezone": "UTC",
    "x-ghost-mode": "true",
    "x-cursor-streaming": "true",
    "x-request-id": requestId
  };
}
async function request(fetchImpl, url, options) {
  const parsed = new URL(url);
  if (parsed.origin !== API2 || parsed.username || parsed.password)
    throw fail("invalid_host", "Only the official Cursor API host is allowed.", 400);
  checkSignal(options.signal);
  try {
    const pending = Promise.resolve(fetchImpl(url, { ...options, redirect: "error" })).then((response2) => {
      if (options.signal?.aborted)
        response2.body?.cancel().catch(() => {});
      return response2;
    });
    const response = await interruptible(pending, options.signal);
    checkSignal(options.signal);
    return response;
  } catch (e) {
    throw safeError(e);
  }
}
function httpError(status) {
  return fail(status === 401 || status === 403 ? "authentication_error" : status === 429 ? "quota_exceeded" : "upstream_http_error", `Cursor returned HTTP ${Number.isInteger(status) ? status : 502}.`, status >= 400 && status <= 599 ? status : 502);
}
function grpcStatus(status) {
  if (!/^\d+$/.test(status))
    throw fail("invalid_protocol", "Invalid Cursor RPC status.");
  if (Number(status) !== 0)
    throw fail(Number(status) === 8 ? "quota_exceeded" : "upstream_rpc_error", `Cursor returned RPC status ${Number(status)}.`, Number(status) === 8 ? 429 : 502);
}
function trailer(payload) {
  const lines = text2(payload).split(/\r?\n/);
  const statuses = lines.filter((s) => /^grpc-status\s*:/i.test(s)).map((s) => s.slice(s.indexOf(":") + 1).trim());
  if (statuses.length !== 1)
    throw fail("invalid_protocol", "Missing or ambiguous Cursor RPC status.");
  grpcStatus(statuses[0]);
}
async function* chunks(response, signal) {
  if (!response.body)
    throw fail("invalid_protocol", "Cursor response has no body.");
  const reader = response.body.getReader();
  const off = onAbort(signal, () => {
    reader.cancel().catch(() => {});
  });
  try {
    while (true) {
      checkSignal(signal);
      const { value, done } = await interruptible(reader.read(), signal);
      checkSignal(signal);
      if (done)
        break;
      if (value.length)
        yield value;
    }
  } finally {
    off();
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}
async function readJson(response, signal) {
  let data = empty;
  for await (const part of chunks(response, signal)) {
    if (data.length + part.length > 1024 * 1024)
      throw fail("size_limit", "Cursor JSON response is too large.");
    data = concat(data, part);
  }
  try {
    return JSON.parse(text2(data));
  } catch {
    throw fail("invalid_response", "Cursor returned invalid JSON.");
  }
}
async function* frames(response, signal) {
  const status = response.headers.get("grpc-status");
  if (status !== null)
    grpcStatus(status);
  let buffer = empty;
  for await (const part of chunks(response, signal)) {
    buffer = concat(buffer, part);
    let offset = 0;
    while (offset + 5 <= buffer.length) {
      const flags = buffer[offset];
      const length = new DataView(buffer.buffer, buffer.byteOffset + offset + 1, 4).getUint32(0);
      if (length > MAX_FRAME - 5)
        throw fail("size_limit", "Cursor frame is too large.");
      if (offset + length + 5 > buffer.length)
        break;
      const data = buffer.slice(offset + 5, offset + 5 + length);
      offset += length + 5;
      if (flags === 128) {
        trailer(data);
        yield { end: true };
      } else if (flags === 2)
        throw fail("upstream_rpc_error", "Cursor returned a Connect error.");
      else if (flags !== 0)
        throw fail("unsupported_protocol", "Compressed/unknown Cursor frames are unsupported.");
      else
        yield { data };
    }
    buffer = buffer.slice(offset);
  }
  if (buffer.length)
    throw fail("invalid_protocol", "Truncated Cursor protocol frame.");
}

class Connection {
  constructor({ fetchImpl, token, body, uuid, now, controller }) {
    this.fetchImpl = fetchImpl;
    this.token = token;
    this.body = body;
    this.uuid = uuid;
    this.now = now;
    this.controller = controller;
    this.id = uuid();
    this.seq = 0n;
    this.blobs = new Map;
    this.blobBytes = 0;
  }
  async append(data) {
    checkSignal(this.controller.signal);
    const response = await request(this.fetchImpl, `${API2}/aiserver.v1.BidiService/BidiAppend`, {
      method: "POST",
      headers: headers2(this.token, this.id, this.now()),
      body: envelope(appendRequest(this.id, this.seq, data)),
      signal: this.controller.signal
    });
    if (!response.ok) {
      response.body?.cancel().catch(() => {});
      throw httpError(response.status);
    }
    for await (const frame of frames(response, this.controller.signal)) {
      if (frame.data?.length)
        fields(frame.data);
    }
    this.seq++;
  }
  async open() {
    const signal = this.controller.signal;
    const responsePromise = request(this.fetchImpl, `${API2}/agent.v1.AgentService/RunSSE`, {
      method: "POST",
      headers: headers2(this.token, this.id, this.now()),
      body: envelope(bidiRequest(this.id)),
      signal
    }).then((response) => {
      if (!response.ok) {
        response.body?.cancel().catch(() => {});
        throw httpError(response.status);
      }
      this.response = response;
      if (signal.aborted)
        response.body?.cancel().catch(() => {});
      return response;
    });
    try {
      await Promise.all([responsePromise, this.append(runMessage(this.body, this.uuid(), this.uuid()))]);
      this.iterator = this.events();
      this.body = undefined;
      return this;
    } catch (error2) {
      this.close();
      throw safeError(error2);
    }
  }
  async kv(data) {
    const fs = fields(data);
    only(fs, [1, 2, 3, 4]);
    one(fs, 4, 2, false);
    const id = number(one(fs, 1, 0, false) ?? 0n);
    const requests = fs.filter((f2) => [2, 3].includes(f2.id));
    if (requests.length !== 1 || requests[0].wire !== 2)
      throw fail("unsupported_protocol", "Unsupported Cursor KV request.");
    const f = requests[0], args = fields(f.value);
    only(args, f.id === 2 ? [1] : [1, 2]);
    const blobId = one(args, 1);
    if (!blobId.length || blobId.length > 512)
      throw fail("invalid_protocol", "Invalid Cursor blob ID.");
    const key = Buffer.from(blobId).toString("hex");
    let result = empty;
    if (f.id === 2) {
      const blob = this.blobs.get(key);
      if (blob)
        result = bytes(1, blob);
    } else {
      const blob = one(args, 2);
      const total = this.blobBytes - (this.blobs.get(key)?.length ?? 0) + blob.length;
      if (total > 16 * 1024 * 1024 || !this.blobs.has(key) && this.blobs.size >= 1024)
        throw fail("size_limit", "Cursor session blob limit exceeded.");
      this.blobs.set(key, blob);
      this.blobBytes = total;
    }
    await this.append(bytes(3, concat(uint(1, id), bytes(f.id, result))));
  }
  async* events() {
    for await (const frame of frames(this.response, this.controller.signal)) {
      if (frame.end) {
        yield { type: "done" };
        return;
      }
      for (const f of fields(frame.data)) {
        if (f.wire !== 2)
          throw fail("unsupported_protocol", "Unsupported Cursor server message.");
        if (f.id === 1) {
          const updates = fields(f.value);
          one(updates, 25, 0, false);
          for (const update of updates) {
            if (update.id === 25)
              continue;
            if (update.wire !== 2)
              throw fail("invalid_protocol", "Invalid Cursor interaction update.");
            if (update.id === 1) {
              const delta = one(fields(update.value), 1, 2, false);
              if (delta)
                yield { type: "text", text: text2(delta) };
            } else if ([5, 8].includes(update.id)) {
              const counters = fields(update.value);
              only(counters, [1]);
              one(counters, 1, 0, false);
            } else if (update.id === 14) {
              yield { type: "done", usage: turnUsage(update.value) };
              return;
            } else if (![2, 3, 4, 7, 13, 15, 16, 17].includes(update.id))
              throw fail("unsupported_protocol", "Unsupported Cursor interaction update.");
          }
        } else if (f.id === 2)
          yield { type: "tool", exec: parseExec(f.value) };
        else if (f.id === 3) {} else if (f.id === 4)
          await this.kv(f.value);
        else if (f.id === 5)
          throw fail("remote_abort", "Cursor aborted an execution stream.");
        else if (f.id === 7)
          throw fail("unsupported_builtin", "Cursor requested a non-MCP interaction; denied without execution.");
        else if (f.id === 8) {} else
          throw fail("unsupported_protocol", "Unknown Cursor server request; denied without execution.");
      }
    }
    throw fail("unexpected_eof", "Cursor stream closed without a completion signal.");
  }
  async submit(exec, message) {
    await this.append(toolResult(exec, message));
    await this.append(toolClose(exec));
  }
  close() {
    this.controller.abort();
    this.blobs.clear();
    this.blobBytes = 0;
    this.token = undefined;
    this.body = undefined;
    if (this.response?.body && !this.response.body.locked)
      this.response.body.cancel().catch(() => {});
    this.iterator?.return?.().catch(() => {});
  }
}
var API2 = "https://api2.cursor.sh", WEBSITE = "https://cursor.com";
var init_transport = __esm(() => {
  init_errors();
  init_protocol();
});

// integrations/native-provider/cursor/index.mjs
var exports_cursor = {};
__export(exports_cursor, {
  default: () => cursor_default,
  createCursorProvider: () => createCursorProvider,
  CursorProviderError: () => CursorProviderError
});
import { createHash as createHash4, randomBytes as randomBytes3, randomUUID as randomUUID4 } from "crypto";
function json2(value, depth = 0) {
  if (depth > 64)
    throw invalid2();
  if (value === null || typeof value === "boolean" || typeof value === "string")
    return JSON.stringify(value);
  if (typeof value === "number" && Number.isFinite(value))
    return JSON.stringify(value);
  if (Array.isArray(value))
    return "[" + value.map((v) => json2(v, depth + 1)).join(",") + "]";
  if (object2(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value))) {
    return "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + json2(value[k], depth + 1)).join(",") + "}";
  }
  throw invalid2();
}
function token(value) {
  if (typeof value !== "string" || !value.length || value.length > 65536 || /\s|[\x00-\x1f\x7f]/.test(value)) {
    throw fail("invalid_credential", "Cursor credential is missing or malformed.", 401);
  }
  return value;
}
function expiryMillis(value) {
  if (!Number.isFinite(value) || value <= 0)
    throw fail("invalid_credential", "Cursor expiry is malformed.", 401);
  return value < 1000000000000 ? value * 1000 : value;
}
function credential2(value, now, allowExpired = false) {
  if (!object2(value))
    throw fail("invalid_credential", "Cursor credential is missing or malformed.", 401);
  const result = { accessToken: token(value.accessToken) };
  if (value.refreshToken !== undefined)
    result.refreshToken = token(value.refreshToken);
  if (value.expiresAt !== undefined) {
    result.expiresAt = expiryMillis(value.expiresAt);
  } else {
    try {
      const exp = JSON.parse(Buffer.from(result.accessToken.split(".")[1], "base64url").toString()).exp;
      if (Number.isFinite(exp) && exp > 0)
        result.expiresAt = exp * 1000;
    } catch {}
  }
  if (!allowExpired && result.expiresAt !== undefined && result.expiresAt <= now)
    throw fail("expired_credential", "Cursor credential has expired; refresh or sign in again.", 401);
  return result;
}
function validateBody(input) {
  const encoded = json2(input);
  if (Buffer.byteLength(encoded) > 2 * 1024 * 1024)
    throw fail("size_limit", "Chat request is too large.", 413);
  const body = JSON.parse(JSON.stringify(input));
  if (!object2(body) || typeof body.model !== "string" || !body.model.trim() || body.model.length > 512)
    throw invalid2();
  const allowed = ["model", "messages", "tools", "stream", "stream_options", "tool_choice", "parallel_tool_calls"];
  if (Object.keys(body).some((k) => !allowed.includes(k)))
    throw fail("unsupported_option", "This experimental Cursor transport does not support that completion option.", 400);
  if (body.stream !== undefined && typeof body.stream !== "boolean")
    throw invalid2();
  if (body.stream_options !== undefined && (!object2(body.stream_options) || Object.keys(body.stream_options).some((k) => k !== "include_usage") || ![true, false, undefined].includes(body.stream_options.include_usage)))
    throw invalid2();
  if (body.parallel_tool_calls !== undefined && typeof body.parallel_tool_calls !== "boolean")
    throw invalid2();
  if (!Array.isArray(body.messages) || !body.messages.length || body.messages.length > 1e4)
    throw invalid2();
  validateMessages(body.messages);
  if (body.tools !== undefined && (!Array.isArray(body.tools) || body.tools.length > 512))
    throw invalid2();
  const names2 = new Set;
  for (const tool of body.tools ?? []) {
    const f = tool?.function;
    if (tool?.type !== "function" || !object2(f) || typeof f.name !== "string" || !f.name || f.name.length > 512 || names2.has(f.name))
      throw invalid2();
    if (f.description !== undefined && typeof f.description !== "string")
      throw invalid2();
    if (f.parameters !== undefined && !object2(f.parameters))
      throw invalid2();
    if (f.strict !== undefined && f.strict !== false)
      throw fail("unsupported_option", "Strict function schema enforcement is unavailable in Cursor MCP transport.", 400);
    names2.add(f.name);
  }
  const choice = body.tool_choice;
  if (choice !== undefined && !["auto", "none", "required"].includes(choice)) {
    if (!object2(choice) || Object.keys(choice).some((k) => !["type", "function"].includes(k)) || choice.type !== "function" || !object2(choice.function) || Object.keys(choice.function).some((k) => k !== "name") || typeof choice.function.name !== "string" || !names2.has(choice.function.name))
      throw invalid2();
  }
  if (choice === "required" && !names2.size)
    throw invalid2();
  return body;
}
function permittedTools(body) {
  if (body.tool_choice === "none")
    return [];
  const tools = body.tools ?? [];
  return object2(body.tool_choice) ? tools.filter((t) => t.function.name === body.tool_choice.function.name) : tools;
}
function remoteBody(body) {
  const { tool_choice, ...remote } = body;
  remote.tools = permittedTools(body);
  if (requiresTool(body)) {
    const selection = object2(tool_choice) ? `request the supplied MCP tool with exact native name ${JSON.stringify(tool_choice.function.name)}` : "request at least one of the supplied MCP tools";
    const rule = { role: "system", content: `For each assistant response, including after a native tool result, ${selection} before completing. ` + "Text alone does not satisfy this request. Emit an MCP tool intent; Polycode alone handles execution and permissions." };
    remote.messages = [...body.messages.slice(0, -1), rule, body.messages.at(-1)];
  }
  return remote;
}
function configKey(body) {
  const { messages, stream, stream_options, ...config } = body;
  return hash(json2(config));
}
function assistantMatches(actual, expected, model) {
  if (!actual || actual.role !== "assistant" || (actual.content ?? "") !== (expected.content ?? ""))
    return false;
  if (Object.hasOwn(actual, "model_id") && actual.model_id !== model)
    return false;
  if (Object.keys(actual).some((key) => !["role", "content", "tool_calls", "model_id"].includes(key)))
    return false;
  return json2(actual.tool_calls ?? []) === json2(expected.tool_calls ?? []);
}
function createCursorProvider({
  fetchImpl = globalThis.fetch,
  uuid = randomUUID4,
  randomBytesImpl = randomBytes3,
  now = Date.now,
  sleepImpl = delay,
  pollIntervalMs = 1000,
  maxPollAttempts = 150,
  loginTimeoutMs = 10 * 60 * 1000,
  requestTimeoutMs = 30000,
  sessionTtlMs = 2 * 60 * 1000,
  parkedToolTimeoutMs = 10 * 60 * 60 * 1000 + 5 * 60 * 1000,
  maxSessionMs = 24 * 60 * 60 * 1000,
  maxSessions = 16,
  setTimeoutImpl = setTimeout,
  clearTimeoutImpl = clearTimeout
} = {}) {
  if (typeof setTimeoutImpl !== "function" || typeof clearTimeoutImpl !== "function")
    throw invalid2();
  for (const n of [pollIntervalMs, maxPollAttempts, loginTimeoutMs, requestTimeoutMs, sessionTtlMs, parkedToolTimeoutMs, maxSessionMs, maxSessions]) {
    if (!Number.isSafeInteger(n) || n <= 0 || n > 2147483647)
      throw invalid2();
  }
  let closed = false;
  const operations = new Set;
  const sessions = new Set;
  function live(signal) {
    if (closed)
      throw fail("provider_closed", "Cursor provider is closed.", 503);
    checkSignal(signal);
  }
  function operation(signal, timeoutMs) {
    live(signal);
    const controller = new AbortController;
    const off = onAbort(signal, () => controller.abort());
    const timer = setTimeoutImpl(() => controller.abort(), timeoutMs);
    operations.add(controller);
    return { controller, signal: controller.signal, finish() {
      clearTimeoutImpl(timer);
      off();
      operations.delete(controller);
    } };
  }
  function drop(session) {
    clearTimeoutImpl(session.timer);
    clearTimeoutImpl(session.maxTimer);
    session.off?.();
    sessions.delete(session);
    session.controller.abort();
    session.connection?.close();
    session.base = undefined;
    session.expected = undefined;
  }
  function touch(session, timeoutMs = sessionTtlMs) {
    clearTimeoutImpl(session.timer);
    session.timer = setTimeoutImpl(() => drop(session), timeoutMs);
    session.timer.unref?.();
  }
  async function authResult(response, signal, oldRefresh) {
    if (response.status !== 200) {
      response.body?.cancel().catch(() => {});
      throw httpError(response.status);
    }
    const result = await readJson(response, signal);
    const valid = credential2(result, now());
    if (!valid.refreshToken && oldRefresh)
      valid.refreshToken = oldRefresh;
    return valid;
  }
  async function startLogin({ signal } = {}) {
    const op = operation(signal, loginTimeoutMs);
    const verifier = Buffer.from(randomBytesImpl(32)).toString("base64url");
    const challenge = createHash4("sha256").update(verifier).digest("base64url");
    const id = uuid();
    const url = new URL("/loginDeepControl", WEBSITE);
    url.search = new URLSearchParams({ challenge, uuid: id, mode: "login", redirectTarget: "cli" }).toString();
    const wait = (async () => {
      try {
        for (let attempt = 0;attempt < maxPollAttempts; attempt++) {
          const poll = new URL("/auth/poll", API2);
          poll.search = new URLSearchParams({ uuid: id, verifier }).toString();
          const response = await request(fetchImpl, poll.href, { headers: { "content-type": "application/json" }, signal: op.signal });
          if (response.status !== 404)
            return await authResult(response, op.signal);
          response.body?.cancel().catch(() => {});
          if (attempt + 1 < maxPollAttempts)
            await sleepImpl(Math.min(pollIntervalMs * 1.2 ** attempt, 1e4), op.signal);
        }
        throw fail("login_timeout", "Cursor sign-in did not complete in time.", 408);
      } catch (e) {
        throw safeError(e);
      } finally {
        op.finish();
      }
    })();
    wait.catch(() => {});
    return { url: url.href, instructions: "Open this official Cursor URL and finish sign-in. Polycode will wait for authorization; cancel to stop.", wait };
  }
  async function refresh(input, { signal } = {}) {
    live(signal);
    const old = credential2(input, now(), true);
    if (old.expiresAt !== undefined && old.expiresAt > now() + 60000)
      return old;
    if (!old.refreshToken)
      throw fail("refresh_unavailable", "No Cursor refresh token; sign in again.", 401);
    const op = operation(signal, requestTimeoutMs);
    try {
      const response = await request(fetchImpl, `${API2}/auth/refresh`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${old.refreshToken}` },
        body: "{}",
        signal: op.signal
      });
      return await authResult(response, op.signal, old.refreshToken);
    } catch (e) {
      throw safeError(e);
    } finally {
      op.finish();
    }
  }
  async function models(input, { signal } = {}) {
    live(signal);
    const c = credential2(input, now());
    const op = operation(signal, requestTimeoutMs);
    try {
      const response = await request(fetchImpl, `${API2}/aiserver.v1.AiService/GetUsableModels`, {
        method: "POST",
        headers: { ...headers2(c.accessToken, uuid(), now()), "content-type": "application/json", accept: "application/json", "connect-protocol-version": "1" },
        body: "{}",
        signal: op.signal
      });
      if (!response.ok) {
        response.body?.cancel().catch(() => {});
        throw httpError(response.status);
      }
      const result = await readJson(response, op.signal);
      if (!Array.isArray(result?.models))
        throw fail("invalid_models", "Cursor returned an invalid model catalog.");
      const catalog = new Map;
      for (const item of result.models) {
        if (typeof item?.modelId !== "string" || !item.modelId)
          throw fail("invalid_models", "Cursor model catalog is missing a canonical model ID.");
        const name = item.displayName ?? item.modelId;
        const contextWindow = item.contextWindow ?? null;
        if (typeof name !== "string" || !name || contextWindow !== null && (!Number.isSafeInteger(contextWindow) || contextWindow <= 0))
          throw fail("invalid_models", "Cursor returned invalid model metadata.");
        const model = { id: item.modelId, name, contextWindow };
        if (catalog.has(model.id) && json2(catalog.get(model.id)) !== json2(model))
          throw fail("invalid_models", "Cursor returned conflicting model IDs.");
        catalog.set(model.id, model);
      }
      return [...catalog.values()];
    } catch (e) {
      throw safeError(e);
    } finally {
      op.finish();
    }
  }
  async function prepare(body, c, signal) {
    const account = hash(c.accessToken), config = configKey(body), base = json2(body.messages);
    const last = body.messages.at(-1);
    let session;
    if (last.role === "tool") {
      const prefix = json2(body.messages.slice(0, -2));
      const matches = [...sessions].filter((s) => s.account === account && s.base === prefix && s.expected && assistantMatches(body.messages.at(-2), s.expected, body.model) && last.tool_call_id === s.pending.toolCallId);
      if (matches.length !== 1 || matches[0].config !== config) {
        const pending = [...sessions].filter((s) => s.account === account && s.pending?.toolCallId === last.tool_call_id);
        const reason = matches.length > 1 || pending.length > 1 ? "Multiple live Cursor calls match this result." : pending.length === 0 ? "No live Cursor call owns this result; the turn may have expired or been closed." : pending[0].config !== config ? "Cursor configuration changed while a native tool call was pending." : pending[0].base !== prefix ? "Cursor transcript changed while a native tool call was pending (for example, compaction or context injection)." : "The native assistant message differs from the pending Cursor call.";
        throw fail("continuation_mismatch", `${reason} Do not replay; restart explicitly.`, 409);
      }
      session = matches[0];
      if (session.busy)
        throw fail("session_busy", "Cursor continuation is already in progress.", 409);
      session.busy = true;
    } else {
      if (last.role !== "user")
        throw invalid2();
      if ([...sessions].some((s) => s.account === account && s.config === config && s.base === base))
        throw fail("session_busy", "This Cursor transcript already has an active or pending turn.", 409);
      if (sessions.size >= maxSessions)
        throw fail("session_limit", "Cursor session limit reached; finish or close existing sessions.", 429);
      session = {
        account,
        config,
        base,
        busy: true,
        controller: new AbortController,
        seen: new Set(body.messages.flatMap((m) => (m.tool_calls ?? []).map((c2) => c2.id)))
      };
      sessions.add(session);
      session.maxTimer = setTimeoutImpl(() => drop(session), maxSessionMs);
      session.maxTimer.unref?.();
    }
    session.off = onAbort(signal, () => drop(session));
    touch(session);
    try {
      if (last.role === "tool") {
        if (last.name !== undefined && last.name !== session.pending.toolName)
          throw fail("continuation_mismatch", "Native tool result name does not match the pending Cursor call.", 409);
        await session.connection.submit(session.pending, last);
        session.base = base;
        session.pending = undefined;
        session.expected = undefined;
      } else {
        session.connection = new Connection({ fetchImpl, token: c.accessToken, body: remoteBody(body), uuid, now, controller: session.controller });
        await session.connection.open();
      }
      checkSignal(session.controller.signal);
      return session;
    } catch (e) {
      drop(session);
      throw safeError(e);
    }
  }
  async function* turn(session, body) {
    let content = "";
    const names2 = new Set(permittedTools(body).map((t) => t.function.name));
    const mustCall = requiresTool(body);
    try {
      while (true) {
        checkSignal(session.controller.signal);
        const result = await session.connection.iterator.next();
        checkSignal(session.controller.signal);
        if (result.done)
          throw fail("unexpected_eof", "Cursor stream ended unexpectedly.");
        const event = result.value;
        touch(session);
        if (event.type === "text") {
          content += event.text;
          if (Buffer.byteLength(content) > 4 * 1024 * 1024)
            throw fail("size_limit", "Cursor completion is too large.");
          if (!mustCall)
            yield { delta: { content: event.text } };
        } else if (event.type === "tool") {
          const exec = event.exec;
          if (!names2.has(exec.toolName))
            throw fail("unregistered_tool", "Cursor requested a tool not permitted by the native engine tool definitions/choice; denied.", 502);
          if (session.seen.has(exec.toolCallId))
            throw fail("duplicate_tool_call", "Cursor reused a tool call ID; denied.");
          if (session.seen.size >= 1024)
            throw fail("size_limit", "Cursor tool call limit exceeded.");
          session.seen.add(exec.toolCallId);
          const call = { id: exec.toolCallId, type: "function", function: { name: exec.toolName, arguments: JSON.stringify(exec.args) } };
          session.pending = exec;
          session.expected = { role: "assistant", content: content || null, tool_calls: [call] };
          if (mustCall && content)
            yield { delta: { content } };
          checkSignal(session.controller.signal);
          yield { delta: { tool_calls: [{ index: 0, ...call }] } };
          checkSignal(session.controller.signal);
          yield { finish_reason: "tool_calls" };
          checkSignal(session.controller.signal);
          return;
        } else if (event.type === "done") {
          if (mustCall)
            throw fail("tool_choice_unfulfilled", "Cursor completed without the required native tool intent; denied.");
          yield { finish_reason: "stop", usage: event.usage };
          checkSignal(session.controller.signal);
          return;
        }
      }
    } catch (e) {
      drop(session);
      throw safeError(e);
    }
  }
  async function complete(input, inputCredential, { signal } = {}) {
    let session;
    try {
      let release = function() {
        session.busy = false;
        session.off?.();
        session.off = undefined;
        if (sessions.has(session)) {
          if (session.pending)
            touch(session, parkedToolTimeoutMs);
          else
            drop(session);
        }
      };
      live(signal);
      const body = validateBody(input);
      const c = credential2(inputCredential, now());
      session = await prepare(body, c, signal);
      const id = `chatcmpl-${uuid()}`, created = Math.floor(now() / 1000);
      const iterator = turn(session, body);
      if (!body.stream) {
        let content = "", calls, finishReason, usage2;
        for await (const part of iterator) {
          if (part.delta?.content)
            content += part.delta.content;
          if (part.delta?.tool_calls)
            calls = part.delta.tool_calls.map(({ index, ...call }) => call);
          if (part.finish_reason)
            finishReason = part.finish_reason;
          if (part.usage !== undefined)
            usage2 = part.usage;
        }
        checkSignal(session.controller.signal);
        release();
        return responseJSON({ id, object: "chat.completion", created, model: body.model, choices: [{ index: 0, message: { role: "assistant", content: content || null, ...calls ? { tool_calls: calls } : {} }, finish_reason: finishReason }], ...usage2 === undefined ? {} : { usage: usage2 } });
      }
      const encoder2 = new TextEncoder;
      const includeUsage = body.stream_options?.include_usage === true;
      const chunk = (delta, finish_reason = null) => ({ id, object: "chat.completion.chunk", created, model: body.model, choices: [{ index: 0, delta, finish_reason }], ...includeUsage ? { usage: null } : {} });
      let started = false, terminal = false, usage;
      const stream = new ReadableStream({
        async pull(controller) {
          if (terminal)
            return;
          const emit = (value) => controller.enqueue(encoder2.encode(`data: ${typeof value === "string" ? value : JSON.stringify(value)}

`));
          try {
            checkSignal(session.controller.signal);
            if (!started && !requiresTool(body)) {
              started = true;
              emit(chunk({ role: "assistant" }));
              return;
            }
            const { value, done } = await iterator.next();
            checkSignal(session.controller.signal);
            if (!started) {
              started = true;
              emit(chunk({ role: "assistant" }));
            }
            if (done) {
              terminal = true;
              if (includeUsage)
                emit({ ...chunk({}), choices: [], usage: usage ?? null });
              emit("[DONE]");
              controller.close();
              release();
            } else {
              if (value.usage !== undefined)
                usage = value.usage;
              emit(chunk(value.delta ?? {}, value.finish_reason ?? null));
            }
          } catch (e) {
            terminal = true;
            drop(session);
            try {
              emit(errorBody(e));
              emit("[DONE]");
              controller.close();
            } catch {}
          }
        },
        cancel() {
          terminal = true;
          drop(session);
          iterator.return().catch(() => {});
        }
      });
      return new Response(stream, { headers: { "content-type": "text/event-stream", "cache-control": "no-store", connection: "keep-alive" } });
    } catch (e) {
      if (session)
        drop(session);
      const error2 = safeError(e);
      return responseJSON(errorBody(error2), error2.status);
    }
  }
  function close() {
    if (closed)
      return;
    closed = true;
    for (const op of operations)
      op.abort();
    operations.clear();
    for (const session of [...sessions])
      drop(session);
  }
  return { startLogin, refresh, models, complete, close };
}
var invalid2 = () => fail("invalid_request", "Invalid or unsupported Chat Completions request.", 400), object2 = (x) => x !== null && typeof x === "object" && !Array.isArray(x), hash = (value) => createHash4("sha256").update(value).digest("hex"), requiresTool = (body) => body.tool_choice === "required" || object2(body.tool_choice), responseJSON = (value, status = 200) => new Response(JSON.stringify(value), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } }), cursor_default;
var init_cursor = __esm(() => {
  init_errors();
  init_transport();
  init_content();
  cursor_default = createCursorProvider;
});

// integrations/native-provider/launch.mjs
import { spawn } from "child_process";
import { homedir } from "os";
import { join as join2, isAbsolute } from "path";
import { pathToFileURL } from "url";

// integrations/native-provider/service.mjs
import { createServer } from "http";
import { randomBytes, randomUUID as randomUUID2, timingSafeEqual } from "crypto";

// integrations/native-provider/store.mjs
var import_proper_lockfile = __toESM(require_proper_lockfile(), 1);
import { mkdir, readFile, writeFile, unlink } from "fs/promises";
import { renameSync } from "fs";
import { join, resolve } from "path";
import { randomUUID } from "crypto";

class CredentialStore {
  constructor(directory) {
    this.directory = resolve(directory);
  }
  path(provider) {
    if (!["codex", "cursor"].includes(provider))
      throw new Error("Unknown subscription provider");
    return join(this.directory, provider + ".json");
  }
  async snapshot(provider) {
    try {
      const data = await readFile(this.path(provider), "utf8");
      if (data.length > 65536)
        throw new Error("Invalid credential store");
      const value = JSON.parse(data);
      if (value.version !== 1 || typeof value.revision !== "string" || !value.credential)
        throw new Error("Invalid credential revision");
      return value;
    } catch (e) {
      if (e.code === "ENOENT")
        return { credential: null, revision: null };
      throw e;
    }
  }
  async get(provider) {
    return (await this.snapshot(provider)).credential;
  }
  async set(provider, value, guard = () => true) {
    return (await this.update(provider, () => value, guard)).committed;
  }
  async update(provider, updater, guard = () => true) {
    const file = this.path(provider);
    await mkdir(this.directory, { recursive: true, mode: 448 });
    let compromised = false;
    const release = await import_proper_lockfile.default.lock(file, { realpath: false, stale: 60000, update: 1e4, retries: { retries: 100, minTimeout: 100, maxTimeout: 1000 }, onCompromised: () => {
      compromised = true;
    } });
    let tmp;
    try {
      const before = await this.snapshot(provider);
      const next = await updater(before.credential);
      if (compromised)
        throw new Error("Credential lock was lost");
      if (!guard())
        return { ...before, committed: false };
      if (JSON.stringify(next) === JSON.stringify(before.credential))
        return { ...before, committed: true };
      const after = { version: 1, revision: randomUUID(), credential: next };
      tmp = file + "." + randomUUID() + ".tmp";
      await writeFile(tmp, JSON.stringify(after), { mode: 384 });
      if (compromised)
        throw new Error("Credential lock was lost");
      if (!guard())
        return { ...before, committed: false };
      renameSync(tmp, file);
      tmp = null;
      return { ...after, committed: true };
    } finally {
      if (tmp)
        await unlink(tmp).catch(() => {});
      await release().catch(() => {});
    }
  }
}
// integrations/native-provider/model-settings.mjs
import { createHash } from "crypto";
var efforts = new Set(["none", "minimal", "low", "medium", "high", "xhigh", "max"]);
function codexReasoningMetadata(model) {
  const levels = model.supported_reasoning_levels;
  if (levels == null || Array.isArray(levels) && !levels.length)
    return {};
  if (!Array.isArray(levels))
    throw new Error("Invalid ChatGPT reasoning capabilities");
  const nativeLevels = levels.filter((level) => (typeof level === "string" ? level : level?.effort) !== "ultra");
  if (!nativeLevels.length)
    throw new Error("Unsupported ChatGPT reasoning capability");
  const reasoningEfforts = nativeLevels.map((level) => {
    const value = typeof level === "string" ? level : level?.effort;
    if (!efforts.has(value))
      throw new Error("Unsupported ChatGPT reasoning capability");
    return { id: value, value, label: value, ...typeof level?.description === "string" ? { description: level.description } : {}, default: value === model.default_reasoning_level };
  });
  const result = { reasoningEfforts, ...model.default_reasoning_level != null ? { defaultReasoningEffort: model.default_reasoning_level } : {} };
  validateReasoningMetadata(result);
  return result;
}
function validateReasoningMetadata(model) {
  const options = model.reasoningEfforts ?? [];
  if (!Array.isArray(options) || options.length > efforts.size || options.some((o) => !o || !efforts.has(o.value) || o.id !== o.value || o.label !== o.value || o.description != null && (typeof o.description !== "string" || o.description.length > 8192 || /[\x00-\x08\x0b-\x1f\x7f]/.test(o.description)) || typeof o.default !== "boolean") || new Set(options.map((o) => o.value)).size !== options.length || options.filter((o) => o.default).length > 1)
    throw new Error("Invalid reasoning capabilities");
  if (model.defaultReasoningEffort != null && !options.some((o) => o.value === model.defaultReasoningEffort))
    throw new Error("Invalid default reasoning effort");
}
function validateSelectedEffort(model, body) {
  const fail = (message) => {
    throw Object.assign(new Error(message), { status: 400 });
  };
  if (body.reasoning_effort != null && body.reasoning?.effort != null && body.reasoning_effort !== body.reasoning.effort)
    fail("Conflicting reasoning effort options");
  const effort = body.reasoning_effort ?? body.reasoning?.effort;
  if (effort == null)
    return;
  if (!model.reasoningEfforts?.length)
    fail("Selected model does not expose reasoning effort control");
  if (!model.reasoningEfforts.some((o) => o.value === effort))
    fail("Selected reasoning effort is not advertised by this model");
}
function catalogRevision(credentialRevision, models) {
  return createHash("sha256").update(JSON.stringify([credentialRevision, models])).digest("hex");
}

// integrations/native-provider/diagnostics.mjs
var stages = new Set(["bridge startup", "native process", "model discovery", "credential storage", "provider authorization"]);
var codes = new Set([
  "ENOENT",
  "EACCES",
  "EPERM",
  "EADDRINUSE",
  "ECONNREFUSED",
  "ECONNRESET",
  "ETIMEDOUT",
  "ENOTFOUND",
  "authentication_error",
  "invalid_credential",
  "expired_credential",
  "invalid_response",
  "size_limit",
  "transport_error",
  "login_timeout",
  "cancelled",
  "quota_exceeded",
  "upstream_http_error",
  "refresh_unavailable",
  "invalid_models"
]);
function diagnostic(cause, stage) {
  const safeStage = stages.has(stage) ? stage : "provider operation";
  const code = codes.has(cause?.code) ? cause.code : codes.has(cause?.cause?.code) ? cause.cause.code : "operation_failed";
  const status = Number.isInteger(cause?.status) && cause.status >= 400 && cause.status <= 599 ? ", HTTP " + cause.status : "";
  return "Polycode failed during " + safeStage + " (" + code + status + ").";
}
function stagedError(cause, stage) {
  return Object.assign(new Error(diagnostic(cause, stage)), { cause, stage });
}

// integrations/native-provider/fast.mjs
var FAST_HEADER = "x-polycode-fast";
function codexFastMetadata(model) {
  return { supportsFast: Array.isArray(model.service_tiers) && model.service_tiers.some((tier) => tier?.id === "priority") };
}
function supportsFast(provider, model) {
  return provider === "codex" && model?.supportsFast === true;
}
function applyFast(provider, model, body, header) {
  const fail = (message) => {
    throw Object.assign(new Error(message), { status: 400 });
  };
  if (header != null && header !== "on" && header !== "off")
    fail("Invalid fast mode control.");
  if (body.service_tier != null && body.service_tier !== "priority")
    fail("Unsupported service tier; only priority is supported.");
  if (header === "off" && body.service_tier != null)
    fail("Conflicting fast mode controls.");
  if (header === "on" || body.service_tier === "priority") {
    if (!supportsFast(provider, model))
      fail("Fast mode is unsupported by the selected provider/model catalog. Cursor fast models must be selected with /model.");
    body.service_tier = "priority";
  }
}

// integrations/native-provider/service.mjs
function waiter(promise, signal) {
  if (!signal)
    return promise;
  if (signal.aborted)
    return Promise.reject(new Error("Request cancelled"));
  let stop;
  const aborted = new Promise((_, reject) => {
    stop = () => reject(new Error("Request cancelled"));
    signal.addEventListener("abort", stop, { once: true });
  });
  return Promise.race([promise, aborted]).finally(() => signal.removeEventListener("abort", stop));
}
var error = (message, status = 400) => Object.assign(new Error(message), { status });
var json = (res, status, data) => {
  res.writeHead(status, { "Content-Type": "application/json", "Cache-Control": "no-store" });
  res.end(JSON.stringify(data));
};
var reply = (data) => Response.json(data, { headers: { "Cache-Control": "no-store" } });
var failure = (cause) => ({ error: { message: cause.status ? cause.message : "Subscription provider operation failed. Check login, quota and provider availability.", type: "polycode_provider_error" } });
var names = { codex: "OpenAI / ChatGPT subscription", cursor: "Cursor subscription (experimental)" };
var ALLOWED = new Set(["auth.openai.com", "cursor.com"]);
var LOGIN_FAILURE_CODES = new Set([
  "authentication_error",
  "invalid_credential",
  "expired_credential",
  "invalid_response",
  "size_limit",
  "transport_error",
  "login_timeout",
  "cancelled",
  "quota_exceeded",
  "upstream_http_error"
]);
function loginFailure(cause, stage) {
  const code = stage === "credential storage" ? ["EACCES", "EPERM"].includes(cause?.code) ? "permission_denied" : "credential_store_failed" : LOGIN_FAILURE_CODES.has(cause?.code) ? cause.code : "provider_authorization_failed";
  const status = stage === "provider authorization" && Number.isInteger(cause?.status) && cause.status >= 400 && cause.status <= 599 ? `, HTTP ${cause.status}` : "";
  return `Authorization failed during ${stage} (${code}${status}). Please retry.`;
}

class NativeProviderService {
  constructor(providers, store, { token = randomBytes(32).toString("hex"), loginTimeout = 600000, serve = globalThis.Bun?.serve } = {}) {
    this.providers = providers;
    this.store = store;
    this.token = token;
    this.loginTimeout = loginTimeout;
    this.serve = serve;
    this.attempts = new Map;
    this.catalogs = new Map;
    this.refreshes = new Map;
    this.active = new Set;
    this.server = createServer((req, res) => this.handle(req, res));
  }
  async start() {
    if (this.serve) {
      this.bunServer = this.serve({ hostname: "127.0.0.1", port: 0, idleTimeout: 0, fetch: (request) => this.handleFetch(request) });
      this.url = `http://127.0.0.1:${this.bunServer.port}`;
      return { url: this.url, token: this.token };
    }
    await new Promise((resolve2, reject) => {
      this.server.once("error", reject);
      this.server.listen(0, "127.0.0.1", resolve2);
    });
    this.url = `http://127.0.0.1:${this.server.address().port}`;
    return { url: this.url, token: this.token };
  }
  async credentialSnapshot(provider, signal) {
    if (!this.providers[provider])
      throw error("Unknown subscription provider");
    if (!this.refreshes.has(provider)) {
      const pending = this.store.update(provider, async (existing) => {
        if (!existing)
          throw error("Sign in using /provider or /login inside Polycode.", 401);
        return this.providers[provider].refresh(existing, { signal: AbortSignal.timeout(60000) });
      });
      this.refreshes.set(provider, pending);
      pending.finally(() => this.refreshes.delete(provider)).catch(() => {});
    }
    return waiter(this.refreshes.get(provider), signal);
  }
  async credential(provider, signal) {
    return (await this.credentialSnapshot(provider, signal)).credential;
  }
  async modelsFor(provider, snapshot, refresh, signal) {
    const cached = this.catalogs.get(provider);
    if (!refresh && cached?.revision === snapshot.revision)
      return cached.models;
    const models = await this.providers[provider].models(snapshot.credential, { signal });
    if (!Array.isArray(models) || models.length > 500 || models.some((m) => typeof m.id !== "string" || !m.id || m.id.length > 512 || typeof m.name !== "string" || m.name.length > 512 || /[\x00-\x1f\x7f]/.test(m.id + m.name) || m.contextWindow !== null && (!Number.isSafeInteger(m.contextWindow) || m.contextWindow <= 0)) || new Set(models.map((m) => m.id)).size !== models.length)
      throw new Error("Invalid catalog");
    for (const model of models)
      validateReasoningMetadata(model);
    if ((await this.store.snapshot(provider)).revision !== snapshot.revision)
      throw error("Account changed while loading models; refresh the catalog.", 409);
    this.catalogs.set(provider, { revision: snapshot.revision, models });
    return models;
  }
  async catalog(refresh = false, signal) {
    const providers = [];
    for (const id of Object.keys(this.providers)) {
      let loggedIn = false;
      let models = [], message, revision;
      try {
        loggedIn = Boolean(await this.store.get(id));
      } catch (cause) {
        message = diagnostic(cause, "credential storage");
      }
      if (loggedIn) {
        try {
          const snapshot = await this.credentialSnapshot(id, signal);
          models = await this.modelsFor(id, snapshot, refresh, signal);
          revision = catalogRevision(snapshot.revision, models);
        } catch (cause) {
          message = diagnostic(cause, "model discovery");
        }
      }
      providers.push({ id, name: names[id], loggedIn, models, ...revision ? { catalogRevision: revision } : {}, ...message ? { message } : {} });
    }
    return { providers };
  }
  async login(provider) {
    if (!this.providers[provider])
      throw error("Unknown subscription provider");
    for (const old of this.attempts.values())
      if (old.provider === provider && old.state === "pending")
        this.cancel(old);
    if (this.attempts.size > 100) {
      for (const [id, a] of this.attempts)
        if (a.state !== "pending")
          this.attempts.delete(id);
    }
    const attempt = { id: randomUUID2(), provider, state: "pending", stage: "provider authorization", controller: new AbortController };
    this.attempts.set(attempt.id, attempt);
    attempt.timer = setTimeout(() => this.cancel(attempt, "Authorization timed out."), this.loginTimeout);
    try {
      const flow = await this.providers[provider].startLogin({ signal: attempt.controller.signal });
      const url = new URL(flow.url);
      if (url.protocol !== "https:" || url.port && url.port !== "443" || !ALLOWED.has(url.hostname) || url.username || url.password || url.hash || provider === "codex" && url.hostname !== "auth.openai.com" || provider === "cursor" && url.hostname !== "cursor.com")
        throw error("Invalid authorization URL");
      attempt.completion = flow.wait.then(async (auth) => {
        if (attempt.state !== "pending" || attempt.controller.signal.aborted)
          return;
        if (!auth || typeof auth.accessToken !== "string" || !auth.accessToken)
          throw new Error("Invalid authorization credential");
        attempt.stage = "credential storage";
        const stored = await this.store.set(provider, auth, () => attempt.state === "pending" && !attempt.controller.signal.aborted);
        if (stored === false || attempt.state !== "pending" || attempt.controller.signal.aborted)
          return;
        this.catalogs.delete(provider);
        attempt.state = "completed";
        clearTimeout(attempt.timer);
      }).catch((cause) => {
        if (attempt.state === "pending") {
          attempt.state = "failed";
          attempt.message = loginFailure(cause, attempt.stage);
          clearTimeout(attempt.timer);
        }
      });
      return { attemptId: attempt.id, url: flow.url, instructions: flow.instructions, ...flow.userCode ? { userCode: flow.userCode } : {} };
    } catch (e) {
      this.cancel(attempt);
      throw Object.assign(new Error(diagnostic(e, "provider authorization")), { status: 500 });
    }
  }
  cancel(a, message) {
    if (a.state !== "pending")
      return;
    a.state = "cancelled";
    a.message = message;
    clearTimeout(a.timer);
    a.controller.abort();
  }
  async body(req) {
    let size = 0;
    const parts = [];
    for await (const part of req) {
      size += part.length;
      if (size > 8 * 1024 * 1024)
        throw error("Request too large", 413);
      parts.push(part);
    }
    try {
      return JSON.parse(Buffer.concat(parts).toString() || "{}");
    } catch {
      throw error("Invalid JSON");
    }
  }
  async dispatch(req, readBody, signal) {
    const auth = req.headers.authorization ?? "", expected = `Bearer ${this.token}`;
    if (req.headers.origin || req.headers.host !== new URL(this.url).host || !req.url?.startsWith("/") || Buffer.byteLength(auth) !== Buffer.byteLength(expected) || !timingSafeEqual(Buffer.from(auth), Buffer.from(expected)))
      throw error("Unauthorized local bridge request", 401);
    const url = new URL(req.url, this.url);
    if (req.method === "GET" && url.pathname === "/control/catalog")
      return reply(await this.catalog(false, signal));
    if (req.method === "POST" && url.pathname === "/control/refresh") {
      await readBody();
      return reply(await this.catalog(true, signal));
    }
    if (req.method === "POST" && url.pathname === "/control/fast-capability") {
      const b = await readBody();
      const snapshot = await this.credentialSnapshot(b.provider, signal);
      const models = await this.modelsFor(b.provider, snapshot, true, signal);
      return reply({ supported: supportsFast(b.provider, models.find((m) => m.id === b.model)) });
    }
    if (req.method === "POST" && url.pathname === "/control/validate-model") {
      const b = await readBody();
      const snapshot = await this.credentialSnapshot(b.provider, signal);
      const models = await this.modelsFor(b.provider, snapshot, true, signal);
      if (typeof b.catalogRevision !== "string" || b.catalogRevision !== catalogRevision(snapshot.revision, models))
        throw error("Queued model catalog or credentials changed; select the model again.", 409);
      const model = models.find((m) => m.id === b.model);
      if (!model)
        throw error("Queued model is no longer available", 409);
      validateSelectedEffort(model, { reasoning_effort: b.effort });
      return reply({});
    }
    if (req.method === "POST" && url.pathname === "/control/login/start") {
      const b = await readBody();
      return reply(await this.login(b.provider));
    }
    if (url.pathname === "/control/login/status" && req.method === "GET") {
      const a = this.attempts.get(url.searchParams.get("attemptId"));
      if (!a)
        throw error("Unknown login attempt", 404);
      return reply({ state: a.state, ...a.message ? { message: a.message } : {} });
    }
    if (url.pathname === "/control/login/cancel" && req.method === "POST") {
      const b = await readBody(), a = this.attempts.get(b.attemptId);
      if (!a)
        throw error("Unknown login attempt", 404);
      this.cancel(a);
      return reply({});
    }
    const route = /^\/(codex|cursor)\/v1\/chat\/completions$/.exec(url.pathname);
    if (req.method === "POST" && route) {
      const provider = route[1], body = await readBody();
      if (typeof body.model !== "string")
        throw error("Model is required");
      if (body.model.startsWith(provider + "/"))
        body.model = body.model.slice(provider.length + 1);
      const snapshot = await this.credentialSnapshot(provider, signal);
      const priorityRequested = req.headers[FAST_HEADER] === "on" || body.service_tier === "priority";
      const models = await this.modelsFor(provider, snapshot, priorityRequested, signal);
      const model = models.find((m) => m.id === body.model);
      if (!model)
        throw error("Model is not advertised by the selected provider");
      validateSelectedEffort(model, body);
      applyFast(provider, model, body, req.headers[FAST_HEADER]);
      return this.providers[provider].complete(body, snapshot.credential, { signal });
    }
    throw error("Unknown bridge endpoint", 404);
  }
  async handleFetch(request) {
    const controller = new AbortController;
    this.active.add(controller);
    let reader;
    const finish = () => {
      this.active.delete(controller);
      request.signal.removeEventListener("abort", abort);
      controller.signal.removeEventListener("abort", cancel);
    };
    const cancel = () => {
      reader?.cancel().catch(() => {});
      finish();
    };
    const abort = () => controller.abort();
    request.signal.addEventListener("abort", abort, { once: true });
    controller.signal.addEventListener("abort", cancel, { once: true });
    if (request.signal.aborted)
      abort();
    try {
      const url = new URL(request.url);
      const response = await this.dispatch({ method: request.method, url: url.pathname + url.search, headers: Object.fromEntries(request.headers) }, () => this.body(request.body ?? []), controller.signal);
      reader = response.body?.getReader();
      if (controller.signal.aborted) {
        await reader?.cancel();
        finish();
        return new Response(null, { status: 499 });
      }
      const headers = { "Content-Type": response.headers.get("Content-Type") ?? "application/json", "Cache-Control": "no-store" };
      if (!reader) {
        finish();
        return new Response(null, { status: response.status, headers });
      }
      const body = new ReadableStream({
        async pull(output) {
          try {
            const result = await reader.read();
            if (result.done || controller.signal.aborted) {
              output.close();
              finish();
            } else
              output.enqueue(result.value);
          } catch (cause) {
            output.error(cause);
            finish();
          }
        },
        cancel() {
          controller.abort();
          finish();
        }
      });
      return new Response(body, { status: response.status, headers });
    } catch (cause) {
      finish();
      return Response.json(failure(cause), { status: cause.status ?? 500, headers: { "Cache-Control": "no-store" } });
    }
  }
  async handle(req, res) {
    const controller = new AbortController;
    this.active.add(controller);
    req.on("aborted", () => controller.abort());
    res.on("close", () => {
      if (!res.writableFinished)
        controller.abort();
    });
    try {
      const response = await this.dispatch(req, () => this.body(req), controller.signal);
      res.writeHead(response.status, { "Content-Type": response.headers.get("Content-Type") ?? "application/json", "Cache-Control": "no-store" });
      if (response.body)
        for await (const chunk of response.body) {
          if (controller.signal.aborted)
            break;
          if (!res.write(chunk))
            await new Promise((resolve2) => {
              const settled = () => {
                res.off("drain", settled);
                res.off("close", settled);
                resolve2();
              };
              res.once("drain", settled);
              res.once("close", settled);
            });
        }
      return res.end();
    } catch (e) {
      if (res.headersSent)
        res.destroy();
      else
        json(res, e.status ?? 500, failure(e));
    } finally {
      this.active.delete(controller);
    }
  }
  async close() {
    for (const a of this.attempts.values())
      this.cancel(a);
    for (const c of this.active)
      c.abort();
    await Promise.allSettled([...this.refreshes.values()]);
    for (const p of Object.values(this.providers))
      p.close();
    if (this.bunServer) {
      await this.bunServer.stop(true);
      return;
    }
    this.server.closeAllConnections?.();
    await new Promise((resolve2) => this.server.close(resolve2));
  }
}

// integrations/native-provider/codex.mjs
import { createServer as createServer2 } from "http";
import { createHash as createHash2, randomBytes as randomBytes2, randomUUID as randomUUID3 } from "crypto";
var CLIENT = "app_EMoamEEZ73f0CkXaXp7hrann";
var ISSUER = "https://auth.openai.com";
var CALLBACK = "http://localhost:1455/auth/callback";
var API = "https://chatgpt.com/backend-api/codex";
var cancelled = () => Object.assign(new Error("Login cancelled"), { name: "AbortError" });
function credential(data) {
  if (typeof data.access_token !== "string" || typeof data.refresh_token !== "string" || !Number.isFinite(data.expires_in) || data.expires_in <= 0)
    throw new Error("Invalid OpenAI token response");
  let payload;
  try {
    payload = JSON.parse(Buffer.from(data.access_token.split(".")[1], "base64url").toString());
  } catch {
    throw new Error("Invalid OpenAI access token");
  }
  const accountId = payload["https://api.openai.com/auth"]?.chatgpt_account_id;
  if (typeof accountId !== "string" || !accountId)
    throw new Error("ChatGPT subscription account is required");
  return { accessToken: data.access_token, refreshToken: data.refresh_token, expiresAt: Date.now() + data.expires_in * 1000, accountId };
}
var headers = (c) => ({ Authorization: `Bearer ${c.accessToken}`, "ChatGPT-Account-Id": c.accountId, originator: "polycode", "Content-Type": "application/json" });
var text = (content) => typeof content === "string" ? content : (content ?? []).filter((x) => x.type === "text").map((x) => x.text).join(`
`);
function contentParts(content, output = false) {
  if (typeof content === "string")
    return [{ type: output ? "output_text" : "input_text", text: content }];
  return (content ?? []).map((part) => {
    if (part.type === "text")
      return { type: output ? "output_text" : "input_text", text: part.text };
    if (!output && part.type === "image_url" && typeof part.image_url?.url === "string")
      return { type: "input_image", image_url: part.image_url.url, ...part.image_url.detail ? { detail: part.image_url.detail } : {} };
    throw new Error("Unsupported OpenAI message content");
  });
}
function toResponses(body) {
  const unsupported = (message) => Object.assign(new Error(message), { status: 400 });
  for (const key of ["temperature", "top_p", "max_tokens", "max_completion_tokens", "max_output_tokens", "stop", "seed", "frequency_penalty", "presence_penalty", "logit_bias", "logprobs", "top_logprobs", "n"]) {
    if (body[key] !== undefined && body[key] !== null)
      throw unsupported(`ChatGPT subscription transport does not support ${key}; remove this explicit option.`);
  }
  const allowed = new Set(["model", "messages", "tools", "stream", "stream_options", "tool_choice", "parallel_tool_calls", "response_format", "reasoning_effort", "reasoning", "service_tier"]);
  if (body.service_tier != null && body.service_tier !== "priority")
    throw unsupported("Unsupported ChatGPT service tier.");
  if (Object.keys(body).some((key) => !allowed.has(key) && body[key] != null))
    throw unsupported("Unsupported ChatGPT subscription request option.");
  if (body.reasoning_effort != null && body.reasoning?.effort != null && body.reasoning_effort !== body.reasoning.effort)
    throw unsupported("Conflicting ChatGPT reasoning effort options.");
  if (body.reasoning && Object.keys(body.reasoning).some((key) => !["effort", "summary"].includes(key)))
    throw unsupported("Unsupported ChatGPT reasoning option.");
  if (body.stream_options && Object.keys(body.stream_options).some((key) => key !== "include_usage"))
    throw unsupported("Unsupported ChatGPT stream option.");
  if (!Array.isArray(body.messages) || typeof body.model !== "string" || !body.model)
    throw new Error("Model and messages are required");
  const names2 = new Map, originals = new Map;
  for (const tool of body.tools ?? []) {
    const name = tool.function?.name;
    if (tool.type !== "function" || typeof name !== "string" || !name || names2.has(name))
      throw new Error("Invalid or duplicate function definition");
    const encoded = /^[a-zA-Z0-9_-]{1,64}$/.test(name) ? name : "polycode_" + createHash2("sha256").update(name).digest("hex").slice(0, 40);
    if (originals.has(encoded))
      throw new Error("Conflicting function names");
    names2.set(name, encoded);
    originals.set(encoded, name);
  }
  const input = [], instructions = [];
  for (const message of body.messages) {
    if (["system", "developer"].includes(message.role)) {
      instructions.push(text(message.content));
      continue;
    }
    if (message.role === "tool") {
      if (!message.tool_call_id)
        throw new Error("Missing native tool call ID");
      input.push({ type: "function_call_output", call_id: message.tool_call_id, output: typeof message.content === "string" ? message.content : contentParts(message.content) });
    } else if (["user", "assistant"].includes(message.role)) {
      if (message.content && (typeof message.content !== "string" || message.content.length))
        input.push({ type: "message", role: message.role, content: contentParts(message.content, message.role === "assistant") });
      for (const call of message.tool_calls ?? []) {
        if (!call.id || typeof call.function?.name !== "string" || typeof call.function.arguments !== "string")
          throw new Error("Invalid native tool history");
        input.push({ type: "function_call", call_id: call.id, name: names2.get(call.function.name) ?? call.function.name, arguments: call.function.arguments });
      }
    } else
      throw new Error("Unsupported conversation role");
  }
  let choice = body.tool_choice;
  if (choice && typeof choice === "object") {
    const mapped = names2.get(choice.function?.name);
    if (!mapped)
      throw new Error("Unknown requested tool");
    choice = { type: "function", name: mapped };
  }
  const request = {
    model: body.model,
    input,
    instructions: instructions.join(`

`),
    stream: true,
    store: false,
    tools: (body.tools ?? []).map((t) => ({ type: "function", name: names2.get(t.function.name), description: t.function.description ?? "", parameters: t.function.parameters ?? { type: "object", properties: {} }, strict: t.function.strict ?? false })),
    ...choice ? { tool_choice: choice } : {},
    parallel_tool_calls: body.parallel_tool_calls ?? true,
    include: ["reasoning.encrypted_content"]
  };
  if (body.response_format) {
    const format = body.response_format;
    if (["text", "json_object"].includes(format.type))
      request.text = { format: { type: format.type } };
    else if (format.type === "json_schema" && format.json_schema?.name && format.json_schema?.schema)
      request.text = { format: { ...format.json_schema, type: "json_schema" } };
    else
      throw new Error("Unsupported structured response format");
  }
  if (body.service_tier === "priority")
    request.service_tier = "priority";
  const effort = body.reasoning_effort ?? body.reasoning?.effort;
  if (effort || body.reasoning?.summary)
    request.reasoning = { ...effort ? { effort } : {}, summary: body.reasoning?.summary ?? "auto" };
  return { request, originals };
}
async function* events(stream, signal) {
  const reader = stream.getReader(), decoder = new TextDecoder;
  let buffer = "";
  const cancel = () => {
    reader.cancel().catch(() => {});
  };
  signal.addEventListener("abort", cancel, { once: true });
  if (signal.aborted)
    cancel();
  try {
    while (true) {
      const { value, done } = await reader.read();
      buffer += done ? decoder.decode() : decoder.decode(value, { stream: true });
      buffer = buffer.replace(/\r\n/g, `
`);
      if (buffer.length > 8 * 1024 * 1024)
        throw new Error("Oversized provider frame");
      let end;
      while ((end = buffer.indexOf(`

`)) >= 0) {
        const frame = buffer.slice(0, end);
        buffer = buffer.slice(end + 2);
        const data = frame.split(`
`).filter((x) => x.startsWith("data:")).map((x) => x.slice(5).trimStart()).join(`
`);
        if (data && data !== "[DONE]")
          yield JSON.parse(data);
      }
      if (done)
        break;
    }
    if (buffer.trim())
      throw new Error("Truncated provider event");
  } finally {
    signal.removeEventListener("abort", cancel);
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}
async function translateResponses(response, body, originals) {
  if (!response.ok) {
    throw Object.assign(new Error(`ChatGPT request failed (HTTP ${response.status}); check login, quota and model access.`), { status: response.status });
  }
  if (!response.body)
    throw new Error("Missing provider stream");
  const id = "chatcmpl-" + randomUUID3(), created = Math.floor(Date.now() / 1000);
  const tools = new Map;
  let content = "", reasoning = "", terminal = false, usage;
  let finishReason, textSeen = false, emittedBytes = 0;
  const abort = new AbortController;
  const base = { id, object: "chat.completion.chunk", created, model: body.model };
  const chunk = (delta, finish_reason = null) => ({ ...base, choices: [{ index: 0, delta, finish_reason }] });
  async function* frames() {
    const queue = [];
    const emit = (data) => {
      const encoded = new TextEncoder().encode("data: " + JSON.stringify(data) + `

`);
      emittedBytes += encoded.length;
      if (emittedBytes > 32 * 1024 * 1024)
        throw new Error("Provider output exceeded the response limit");
      finishReason = data.choices?.[0]?.finish_reason ?? finishReason;
      if (body.stream)
        queue.push(encoded);
    };
    const tool = (index, item) => {
      if (tools.has(index)) {
        const existing = tools.get(index);
        if (existing.id !== item.call_id || existing.name !== originals.get(item.name))
          throw new Error("Provider changed a native tool identity");
        return existing;
      }
      const name = originals.get(item.name);
      if (!name || !item.call_id)
        throw new Error("Provider returned an undeclared native tool");
      const entry = { index: tools.size, id: item.call_id, name, arguments: "", argumentLength: 0, outputIndex: index };
      tools.set(index, entry);
      emit(chunk({ tool_calls: [{ index: entry.index, id: entry.id, type: "function", function: { name, arguments: "" } }] }));
      return entry;
    };
    try {
      emit(chunk({ role: "assistant" }));
      while (queue.length)
        yield queue.shift();
      for await (const event of events(response.body, abort.signal)) {
        if (event.type === "response.output_text.delta") {
          textSeen ||= Boolean(event.delta);
          if (!body.stream)
            content += event.delta;
          emit(chunk({ content: event.delta }));
        }
        if (event.type === "response.reasoning_summary_text.delta") {
          if (!body.stream)
            reasoning += event.delta;
          emit(chunk({ reasoning_content: event.delta }));
        }
        if (event.type === "response.output_item.added" && event.item?.type === "function_call")
          tool(event.output_index, event.item);
        if (event.type === "response.function_call_arguments.delta") {
          const t = tools.get(event.output_index);
          if (!t)
            throw new Error("Tool arguments arrived without a declared call");
          t.argumentLength += event.delta.length;
          if (!body.stream)
            t.arguments += event.delta;
          emit(chunk({ tool_calls: [{ index: t.index, function: { arguments: event.delta } }] }));
        }
        if (event.type === "response.output_item.done" && event.item?.type === "function_call") {
          const t = tool(event.output_index, event.item);
          if (!t.argumentLength && event.item.arguments) {
            t.argumentLength = event.item.arguments.length;
            if (!body.stream)
              t.arguments = event.item.arguments;
            emit(chunk({ tool_calls: [{ index: t.index, function: { arguments: event.item.arguments } }] }));
          }
        }
        if (event.type === "error" || event.type === "response.failed")
          throw new Error("ChatGPT generation failed");
        if (["response.completed", "response.incomplete", "response.done"].includes(event.type)) {
          if (event.response?.status === "failed")
            throw new Error("ChatGPT generation failed");
          for (const [index, item] of (event.response?.output ?? []).entries()) {
            if (item.type === "function_call") {
              const t = tool(index, item);
              if (!t.argumentLength && item.arguments) {
                t.argumentLength = item.arguments.length;
                if (!body.stream)
                  t.arguments = item.arguments;
                emit(chunk({ tool_calls: [{ index: t.index, function: { arguments: item.arguments } }] }));
              }
            }
          }
          if (!textSeen) {
            const finalText = (event.response?.output ?? []).filter((x) => x.type === "message").flatMap((x) => x.content ?? []).filter((x) => x.type === "output_text").map((x) => x.text).join("");
            if (finalText) {
              content = finalText;
              emit(chunk({ content }));
            }
          }
          const u = event.response?.usage;
          usage = u ? { prompt_tokens: u.input_tokens ?? 0, completion_tokens: u.output_tokens ?? 0, total_tokens: u.total_tokens ?? (u.input_tokens ?? 0) + (u.output_tokens ?? 0) } : undefined;
          const finish = event.type === "response.incomplete" ? "length" : tools.size ? "tool_calls" : "stop";
          emit({ ...chunk({}, finish), ...usage ? { usage } : {} });
          terminal = true;
          break;
        }
        while (queue.length)
          yield queue.shift();
      }
      if (!terminal)
        throw new Error("Provider stream ended without completion");
      while (queue.length)
        yield queue.shift();
      if (body.stream)
        yield new TextEncoder().encode(`data: [DONE]

`);
    } finally {
      abort.abort();
    }
  }
  const iterator = frames();
  const stream = new ReadableStream({
    async pull(controller) {
      try {
        const result = await iterator.next();
        if (result.done)
          controller.close();
        else
          controller.enqueue(result.value);
      } catch (e) {
        controller.error(e);
      }
    },
    async cancel() {
      abort.abort();
      await iterator.return().catch(() => {});
      if (!response.body.locked)
        await response.body.cancel().catch(() => {});
    }
  });
  if (body.stream)
    return new Response(stream, { headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache" } });
  await new Response(stream).arrayBuffer();
  return Response.json({ id, object: "chat.completion", created, model: body.model, choices: [{ index: 0, message: { role: "assistant", content: content || null, ...reasoning ? { reasoning_content: reasoning } : {}, ...tools.size ? { tool_calls: [...tools.values()].map((t) => ({ id: t.id, type: "function", function: { name: t.name, arguments: t.arguments } })) } : {} }, finish_reason: finishReason }], ...usage ? { usage } : {} });
}
function createCodexProvider({ fetchImpl = fetch, httpFactory = createServer2 } = {}) {
  async function token(fields, signal) {
    const response = await fetchImpl(ISSUER + "/oauth/token", { redirect: "error", method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ client_id: CLIENT, ...fields }), signal });
    if (!response.ok)
      throw Object.assign(new Error(`OpenAI authorization failed (HTTP ${response.status})`), { code: "upstream_http_error", status: response.status });
    return credential(await response.json());
  }
  return {
    async startLogin({ signal }) {
      const verifier = randomBytes2(32).toString("base64url"), state = randomBytes2(32).toString("hex");
      const challenge = createHash2("sha256").update(verifier).digest("base64url");
      let accept, reject, settled = false;
      const wait = new Promise((a, b) => {
        accept = a;
        reject = b;
      });
      wait.catch(() => {});
      const server = httpFactory(async (req, res) => {
        const url2 = new URL(req.url ?? "/", CALLBACK);
        if (req.method !== "GET" || url2.pathname !== "/auth/callback" || url2.searchParams.get("state") !== state || settled) {
          res.writeHead(400);
          res.end("Invalid authorization callback.");
          return;
        }
        if (url2.searchParams.has("error")) {
          settled = true;
          res.writeHead(400);
          res.end("Authorization was denied. Return to Polycode to retry.");
          reject(new Error("OpenAI authorization was denied"));
          server.close();
          return;
        }
        if (!url2.searchParams.get("code")) {
          res.writeHead(400);
          res.end("Authorization was not completed.");
          return;
        }
        settled = true;
        try {
          const auth = await token({ grant_type: "authorization_code", code: url2.searchParams.get("code"), code_verifier: verifier, redirect_uri: CALLBACK }, signal);
          res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
          res.end("Polycode login completed. Return to the terminal.");
          accept(auth);
        } catch (e) {
          res.writeHead(400);
          res.end("Authorization failed. Return to Polycode to retry.");
          reject(e);
        } finally {
          server.close();
        }
      });
      await new Promise((a, b) => {
        server.once("error", b);
        server.listen(1455, "127.0.0.1", a);
      });
      const abort = () => {
        settled = true;
        server.close();
        reject(cancelled());
      };
      signal.addEventListener("abort", abort, { once: true });
      if (signal.aborted)
        abort();
      wait.finally(() => signal.removeEventListener("abort", abort)).catch(() => {});
      const url = new URL(ISSUER + "/oauth/authorize");
      url.search = new URLSearchParams({ response_type: "code", client_id: CLIENT, redirect_uri: CALLBACK, scope: "openid profile email offline_access", code_challenge: challenge, code_challenge_method: "S256", state, id_token_add_organizations: "true", codex_cli_simplified_flow: "true", originator: "polycode" }).toString();
      return { url: url.href, instructions: "Complete ChatGPT subscription authorization in your browser, then return to Polycode.", wait };
    },
    async refresh(c, { signal } = {}) {
      if (c.expiresAt > Date.now() + 60000)
        return c;
      return token({ grant_type: "refresh_token", refresh_token: c.refreshToken }, signal);
    },
    async models(c, { signal } = {}) {
      const r = await fetchImpl(API + "/models?client_version=0.153.4", { redirect: "error", headers: headers(c), signal });
      if (!r.ok)
        throw Object.assign(new Error(`ChatGPT model discovery failed (HTTP ${r.status})`), { code: "upstream_http_error", status: r.status });
      const data = await r.json(), models = data.models ?? data.data;
      if (!Array.isArray(models))
        throw new Error("Invalid ChatGPT model catalog");
      return models.filter((m) => m.visibility !== "hide").map((m) => ({ id: m.slug ?? m.id ?? m.model, name: m.display_name ?? m.displayName ?? m.slug ?? m.id, contextWindow: m.context_window ?? m.contextWindow ?? 128000, ...codexReasoningMetadata(m), ...codexFastMetadata(m) }));
    },
    async complete(body, c, { signal } = {}) {
      const { request, originals } = toResponses(body);
      const response = await fetchImpl(API + "/responses", { redirect: "error", method: "POST", headers: { ...headers(c), Accept: "text/event-stream" }, body: JSON.stringify(request), signal });
      return translateResponses(response, body, originals);
    },
    close() {}
  };
}

// integrations/native-provider/launch.mjs
function defaultAuthDirectory(platform = process.platform, env = process.env, home = homedir()) {
  return platform === "win32" ? join2(env.LOCALAPPDATA || join2(home, "AppData", "Local"), "Polycode", "auth") : join2(env.XDG_DATA_HOME || join2(home, ".local", "share"), "polycode", "auth");
}
async function runNative({ binary, cwd, provider = "auto", resume, nativeArgs = [], providers, directory, spawnChild = spawn }) {
  if (!isAbsolute(binary) || !isAbsolute(cwd))
    throw new Error("Absolute native binary and workspace paths are required");
  if (!["auto", "native", "codex", "cursor"].includes(provider))
    throw new Error("Unknown initial provider");
  if (!Array.isArray(nativeArgs) || nativeArgs.some((arg) => typeof arg !== "string" || arg.includes("\x00")))
    throw new Error("Invalid native arguments");
  const service = new NativeProviderService(providers, new CredentialStore(directory));
  let bridge;
  try {
    bridge = await service.start();
  } catch (cause) {
    await service.close();
    throw stagedError(cause, "bridge startup");
  }
  const args = ["--cwd", cwd, "--no-external-acp", "--polycode-native"];
  if (provider !== "auto")
    args.push("--polycode-provider", provider);
  if (resume)
    args.push("--resume", resume);
  args.push(...nativeArgs);
  let child;
  const stop = () => child?.kill("SIGTERM");
  const interrupt = () => {};
  try {
    child = spawnChild(binary, args, { cwd, stdio: "inherit", env: { ...process.env, POLYCODE_BRIDGE_URL: bridge.url, POLYCODE_BRIDGE_TOKEN: bridge.token } });
    process.on("SIGTERM", stop);
    process.on("SIGINT", interrupt);
    if (process.platform !== "win32")
      process.on("SIGHUP", stop);
    return await new Promise((resolve2, reject) => {
      child.once("error", reject);
      child.once("exit", (code) => resolve2(code ?? 1));
    });
  } catch (cause) {
    throw stagedError(cause, "native process");
  } finally {
    process.removeListener("SIGTERM", stop);
    process.removeListener("SIGINT", interrupt);
    process.removeListener("SIGHUP", stop);
    await service.close();
  }
}
function parseArguments(argv) {
  const options = {};
  for (let i = 0;i < argv.length; i += 2) {
    if (argv[i] === "--")
      return { options, nativeArgs: argv.slice(i + 1) };
    if (!["--binary", "--cwd", "--provider", "--resume", "--auth-directory"].includes(argv[i]) || !argv[i + 1] || argv[i + 1] === "--" || Object.hasOwn(options, argv[i].slice(2)))
      throw new Error("Invalid native launcher arguments");
    options[argv[i].slice(2)] = argv[i + 1];
  }
  return { options, nativeArgs: [] };
}
async function main(argv = process.argv.slice(2)) {
  const { options, nativeArgs } = parseArguments(argv);
  const { createCursorProvider: createCursorProvider2 } = await Promise.resolve().then(() => (init_cursor(), exports_cursor));
  const providers = { codex: createCodexProvider(), cursor: createCursorProvider2() };
  return runNative({ binary: options.binary, cwd: options.cwd, provider: options.provider, resume: options.resume, nativeArgs, providers, directory: options["auth-directory"] ?? defaultAuthDirectory() });
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().then((code) => process.exit(code), (cause) => {
    console.error(diagnostic(cause.cause ?? cause, cause.stage));
    process.exit(1);
  });
}
export {
  runNative,
  parseArguments,
  main,
  defaultAuthDirectory
};
